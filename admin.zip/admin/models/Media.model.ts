import mongoose, { Document, Model, Schema } from "mongoose";

export interface IMedia extends Document {
  asset_id: string;
  public_id: string;
  folder: string;
  thumbnail_url: string;
  secure_url: string;
  alt?: string;
  title?: string;
  deletedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

const mediaSchema: Schema<IMedia> = new mongoose.Schema(
  {
    asset_id: {
      type: String,
      required: true,
      trim: true,
    },
    public_id: {
      type: String,
      required: true,
      trim: true,
    },
    folder: {
      type: String,
      required: true,
      trim: true,
    },
    thumbnail_url: {
      type: String,
      required: true,
      trim: true,
    },
    secure_url: {
      type: String,
      required: true,
      trim: true,
    },
    alt: {
      type: String,
      trim: true,
    },
    title: {
      type: String,
      trim: true,
    },
    deletedAt: {
      type: Date,
      default: null,
      index: true,
    },
  },
  { timestamps: true }
);

const MediaModel: Model<IMedia> =
  mongoose.models.Media ||
  mongoose.model<IMedia>("Media", mediaSchema, "medias");

export default MediaModel;