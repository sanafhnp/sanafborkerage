"use client";

import React from "react";
import {
  FEATURES_LIST,
  AMENITIES_LIST,
  OTHER_FEATURES_LIST,
} from "../lib/property/propertySchema";

interface DescriptionFormProps {
  data: any;
  setData: React.Dispatch<React.SetStateAction<any>>;
  errors: Record<string, string>;
  setErrors: React.Dispatch<React.SetStateAction<Record<string, string>>>;
  onNext: () => void;
  onBack: () => void;
}

export default function DescriptionForm({
  data,
  setData,
  errors,
  setErrors,
  onNext,
  onBack,
}: DescriptionFormProps) {
  // 🔥 Clear error when user types
  const handleChange = (field, value) => {
    setData((prev) => ({
      ...prev,
      [field]: value,
    }));

    setErrors((prev) => {
      const newErrors = { ...prev };
      delete newErrors[field];
      return newErrors;
    });
  };

  // 🔥 Checkbox handler
  const handleCheckbox = (field, value, checked) => {
    setData((prev) => {
      const currentArray = prev[field] || [];

      if (checked) {
        return {
          ...prev,
          [field]: [...currentArray, value],
        };
      } else {
        return {
          ...prev,
          [field]: currentArray.filter((item) => item !== value),
        };
      }
    });
  };

  const features = FEATURES_LIST;
  const amenities = AMENITIES_LIST;
  const otherFeatures = OTHER_FEATURES_LIST;

  return (
    <div className="bg-card text-card-foreground rounded-xl shadow p-6 mt-6 border border-border">
      {/* Top Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {["floor", "bed", "bath", "balcony"].map((field) => (
          <div key={field}>
            <label className="block font-medium mb-2 capitalize">{field}</label>
            <input
              type="number"
              value={data[field] || ""}
              onChange={(e) => handleChange(field, e.target.value)}
              className="w-full border border-input bg-background rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder={`Number of ${field}`}
            />
            {errors[field] && (
              <p className="text-destructive text-sm mt-1">{errors[field]}</p>
            )}
          </div>
        ))}
      </div>

      {/* Description */}
      <div className="mt-6">
        <label className="block font-medium mb-2">Description</label>
        <textarea
          value={data.description || ""}
          onChange={(e) => handleChange("description", e.target.value)}
          className="w-full border border-input bg-background rounded-lg p-3 h-32 focus:outline-none focus:ring-2 focus:ring-primary"
          placeholder="Detailed property description..."
        />
        {errors.description && (
          <p className="text-destructive text-sm mt-1">{errors.description}</p>
        )}
      </div>

      {/* Contact Phone */}
      <div className="mt-6 max-w-md">
        <label className="block font-medium mb-2">Contact Phone</label>
        <input
          type="text"
          value={data.phone || ""}
          onChange={(e) => handleChange("phone", e.target.value)}
          className="w-full border border-input bg-background rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-primary"
          placeholder="Phone number"
        />
        {errors.phone && (
          <p className="text-destructive text-sm mt-1">{errors.phone}</p>
        )}
      </div>

      <Section title="Features">
        <CheckboxGrid
          items={features}
          field="features"
          data={data}
          onChange={handleCheckbox}
        />
      </Section>

      <Section title="Amenities">
        <CheckboxGrid
          items={amenities}
          field="amenities"
          data={data}
          onChange={handleCheckbox}
        />
      </Section>

      <Section title="Other Features">
        <CheckboxGrid
          items={otherFeatures}
          field="otherFeatures"
          data={data}
          onChange={handleCheckbox}
        />
      </Section>

      {/* Buttons */}
      <div className="mt-10 flex justify-between">
        <button
          onClick={onBack}
          className="bg-secondary text-secondary-foreground px-8 py-3 rounded-lg font-semibold hover:bg-secondary/80 transition-colors"
        >
          Back to Step 1
        </button>

        <button
          onClick={onNext}
          className="bg-primary text-primary-foreground px-8 py-3 rounded-lg font-semibold hover:bg-primary/90 transition-colors"
        >
          Next Step: Attachments
        </button>
      </div>
    </div>
  );
}

/* Reusable Components */

function Section({ title, children }) {
  return (
    <div className="mt-8">
      <h3 className="text-lg font-semibold mb-4">{title}</h3>
      {children}
    </div>
  );
}

function CheckboxGrid({ items, field, data, onChange }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {items.map((item, i) => (
        <label
          key={i}
          className="flex items-center gap-2 cursor-pointer group"
        >
          <input
            type="checkbox"
            checked={(data[field] || []).includes(item)}
            onChange={(e) => onChange(field, item, e.target.checked)}
            className="w-4 h-4 rounded border-input bg-background text-primary focus:ring-primary"
          />
          <span className="text-sm group-hover:text-primary transition-colors">
            {item}
          </span>
        </label>
      ))}
    </div>
  );
}
