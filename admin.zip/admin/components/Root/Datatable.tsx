"use client";

import { IconButton, Tooltip } from "@mui/material";
import { useQuery, keepPreviousData } from "@tanstack/react-query";
import axios from "axios";
import {
  MaterialReactTable,
  MRT_ShowHideColumnsButton,
  MRT_ToggleDensePaddingButton,
  MRT_ToggleFullScreenButton,
  MRT_ToggleGlobalFilterButton,
  useMaterialReactTable,
} from "material-react-table";
import React, { useState } from "react";
import DeleteIcon from "@mui/icons-material/Delete";
import RestoreTrashIcon from "@mui/icons-material/RestoreFromTrash";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import SaveAltIcon from "@mui/icons-material/SaveAlt";
import useDeleteMutation from "@/hooks/useDeleteMutation";
import { showToast } from "@/lib/showToast";
import { download, generateCsv, mkConfig } from "export-to-csv";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useRouter } from "next/navigation";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";

const Datatable = ({
  queryKey,
  fetchUrl,
  columnConfig,
  initialPageSize = 10,
  exportEndpoint,
  deleteEndpoint,
  deleteType,
  trashView,
  createAction,
  restoreRedirect,
  deleteRedirect,
  backLink,
}) => {
  const [columnFilters, setColumnFilters] = useState([]);
  const [globalFilter, setGlobalFilter] = useState("");
  const [sorting, setSorting] = useState([]);
  const [pagination, setPagination] = useState({
    pageIndex: 0,
    pageSize: initialPageSize,
  });
  const [rowSelection, setRowSelection] = useState({});
  const [exportLoading, setExportLoading] = useState(false);
  const router = useRouter();

  const deleteMutation = useDeleteMutation(queryKey, deleteEndpoint);

  const handleDelete = async (ids, deleteType) => {
    if (!ids?.length) {
      showToast("error", "Please select at least one row.");
      return;
    }

    try {
      await deleteMutation.mutateAsync({ ids, deleteType });
      setRowSelection({});
      showToast("success", "Action completed successfully.");
      if (trashView === true && deleteType === "restore" && restoreRedirect) {
        router.push(restoreRedirect);
      } else if (trashView === true && deleteType === "PD" && deleteRedirect) {
        router.push(deleteRedirect);
      }
    } catch (error: any) {
      showToast("error", error.message);
    }
  };

  const handleExport = async () => {
    try {
      setExportLoading(true);
      const selectedIds = Object.keys(rowSelection)
        .map((key) => {
          const idx = Number(key);
          return data[idx]?._id;
        })
        .filter(Boolean);

      let finalUrl: URL;
      if (exportEndpoint.startsWith("http")) {
        finalUrl = new URL(exportEndpoint);
      } else {
        const path = exportEndpoint.startsWith("/api")
          ? exportEndpoint
          : `/api${
              exportEndpoint.startsWith("/") ? "" : "/"
            }${exportEndpoint}`;
        finalUrl = new URL(path, window.location.origin);
      }

      if (selectedIds.length) {
        finalUrl.searchParams.set("ids", selectedIds.join(","));
      }

      const { data: response } = await axios.get(finalUrl.href, { withCredentials: true });

      const csvConfig = mkConfig({
        useKeysAsHeaders: true,
        filename: "csv-data",
      });

      const csv = generateCsv(csvConfig)(response.data);
      download(csvConfig)(csv);

      showToast("success", "Export successful.");
    } catch {
      showToast("error", "Export failed.");
    } finally {
      setExportLoading(false);
    }
  };

  const {
    data: { data = [], meta } = {},
    isRefetching,
    isLoading,
  } = useQuery({
    queryKey: [queryKey, { columnFilters, globalFilter, pagination, sorting }],
    queryFn: async () => {
      let finalUrl;
      if (fetchUrl.startsWith("http")) {
        finalUrl = new URL(fetchUrl);
      } else {
        // If it doesn't start with /api, add it to leverage Next.js rewrites
        const path = fetchUrl.startsWith("/api") ? fetchUrl : `/api${fetchUrl.startsWith("/") ? "" : "/"}${fetchUrl}`;
        finalUrl = new URL(path, window.location.origin);
      }

      finalUrl.searchParams.set(
        "start",
        `${pagination.pageIndex * pagination.pageSize}`,
      );
      finalUrl.searchParams.set("size", `${pagination.pageSize}`);
      finalUrl.searchParams.set("filters", JSON.stringify(columnFilters));
      finalUrl.searchParams.set("globalFilter", globalFilter);
      finalUrl.searchParams.set("sorting", JSON.stringify(sorting));
      finalUrl.searchParams.set("deleteType", deleteType);

      const { data } = await axios.get(finalUrl.href, { withCredentials: true });
      return data;
    },
    placeholderData: keepPreviousData,
  });

  const isTrashView = trashView === true;
  const trashLink = typeof trashView === "string" ? trashView : null;
  const getSelectedIds = () =>
    Object.keys(rowSelection)
      .map((key) => {
        const idx = Number(key);
        return data[idx]?._id;
      })
      .filter(Boolean);

  const table = useMaterialReactTable({
    columns: columnConfig ?? [],
    data,
    manualFiltering: true,
    manualPagination: true,
    manualSorting: true,
    rowCount: meta?.totalRowCount ?? 0,

    enableRowSelection: true,
    onRowSelectionChange: setRowSelection,

    state: {
      columnFilters,
      globalFilter,
      pagination,
      sorting,
      rowSelection,
      isLoading,
      showProgressBars: isRefetching,
    },

    onColumnFiltersChange: setColumnFilters,
    onGlobalFilterChange: setGlobalFilter,
    onPaginationChange: setPagination,
    onSortingChange: setSorting,

    renderTopToolbarCustomActions: () => (
      <div className="flex gap-2">
        {backLink && (
          <Button asChild variant="outline" size="sm" className="cursor-pointer">
            <Link href={backLink}>
              <ArrowBackIcon fontSize="small" />
              Back
            </Link>
          </Button>
        )}
        <Button
          className='cursor-pointer'
          onClick={handleExport}
        >
          <SaveAltIcon color="info" />
          Export
        </Button>

        {trashLink && (
          <Button asChild variant="destructive" className="cursor-pointer">
            <Link href={trashLink}>Trash</Link>
          </Button>
        )}

        {isTrashView ? (
          <>
            <Tooltip title="Restore">
              <IconButton
                onClick={() => handleDelete(getSelectedIds(), "restore")}
              >
                <RestoreTrashIcon color="success" />
              </IconButton>
            </Tooltip>
            <Tooltip title="Delete Forever">
              <IconButton
                onClick={() => handleDelete(getSelectedIds(), "PD")}
              >
                <DeleteForeverIcon color="error" />
              </IconButton>
            </Tooltip>
          </>
        ) : (
          <IconButton
            onClick={() =>
              handleDelete(getSelectedIds(), deleteType || "SD")
            }
          >
            <DeleteIcon color="error" />
          </IconButton>
        )}
      </div>
    ),

    renderToolbarInternalActions: ({ table }) => (
      <>
        <MRT_ToggleGlobalFilterButton table={table} />
        <MRT_ShowHideColumnsButton table={table} />
        <MRT_ToggleDensePaddingButton table={table} />
        <MRT_ToggleFullScreenButton table={table} />
      </>
    ),
    
    enableRowActions: Boolean(createAction),
    positionActionsColumn: 'last',
    renderRowActionMenuItems: ({ row }) => {
      if (!createAction) return []
      return createAction(row, deleteType, handleDelete) || []
    },
  });

  return <MaterialReactTable table={table} />;
};

export default Datatable
