import React from "react";
import DeleteIcom from "@mui/icons-material/Delete";
import { ListItemIcon, MenuItem } from "@mui/material";

const DeleteAction = ({ handleDelete, row, deleteType }) => {
  return (
    <MenuItem key="delete" onClick={() => handleDelete([row.original._id], deleteType)}>
      <ListItemIcon>
        <DeleteIcom />
      </ListItemIcon>
      Delete
    </MenuItem>
  );
};

export default DeleteAction;
