'use client'

import { Button } from "@/components/ui/button"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  useSidebar,
} from "@/components/ui/sidebar"
import logoBlack from '@/public/assets/images/logo-black.png'
import logoWhite from '@/public/assets/images/logo-white.png'
import Image from "next/image"
import { LuChevronRight } from "react-icons/lu";
import { IoMdClose } from "react-icons/io";
import { adminAppSidebarMenu } from "@/lib/adminSidebarMenu"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import Link from "next/link"
 
export function AppSidebar() {
  const { toggleSidebar } = useSidebar()

  return (
    <Sidebar className='z-50'>
      <SidebarHeader className='border-b h-15 p-0'>
        <div className="flex justify-between items-center px-4">
            <Image src={logoBlack} height={50} width={logoBlack.width} className="block dark:hidden h-12.5 w-auto" alt='logo dark'/>
            <Image src={logoWhite} height={50} width={logoWhite.width} className="hidden dark:block h-12.5 w-auto" alt='logo white'/>
            <Button onClick={toggleSidebar} type='button' size="icon" className='md:hidden'>
                <IoMdClose />
            </Button>
        </div>
      </SidebarHeader>

      <SidebarContent className='p-3'>
        <SidebarMenu>
            {adminAppSidebarMenu.map((menu, index) => (
                <Collapsible key={index} className='group/collapsible'>
                    <SidebarMenuItem>
                        <CollapsibleTrigger asChild className='font-semibold px-2 py-5'>
                            <SidebarMenuButton asChild>
                                <Link href={menu?.url}>
                                    <menu.icon />
                                    {menu.title}

                                    {menu.submenu && menu.submenu.length > 0 &&
                                        <LuChevronRight className="ml-auto transition-transform duration-200 group-data-[state=open]/collapsible: rotate-90"/>
                                    }
                                </Link>
                            </SidebarMenuButton>
                        </CollapsibleTrigger>

                        {menu.submenu && menu.submenu.length > 0 &&
                            <CollapsibleContent>
                                <SidebarMenuSub>
                                    {menu.submenu.map((submenuItem, submenuIndex) => (
                                        <SidebarMenuSubItem key={submenuIndex}>
                                                <SidebarMenuSubButton asChild className='px-2 py-5'>
                                                    <Link href={submenuItem.url}>
                                                        {submenuItem.title}
                                                    </Link>
                                                </SidebarMenuSubButton>
                                        </SidebarMenuSubItem>
                                    )) 

                                    }
                                </SidebarMenuSub>
                            </CollapsibleContent>
                        }
                    </SidebarMenuItem>
                </Collapsible>
            ))}
        </SidebarMenu>
      </SidebarContent>
    </Sidebar>
  )
}