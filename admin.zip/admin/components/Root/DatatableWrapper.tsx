'use client'

import { ThemeProvider } from '@mui/material'
import Datatable from './Datatable'
import { useTheme } from 'next-themes'
import { darkTheme, lightTheme } from '@/lib/materialTheme'

const DatatableWrapper = ({
  queryKey,
  fetchUrl,
  columnConfig,
  initialPageSize = 10,
  exportEndpoint,
  deleteEndpoint,
  deleteType,
  trashView,
  createAction,
  restoreRedirect,
  deleteRedirect,
  backLink,
}) => {
  const { resolvedTheme } = useTheme()

  // Prevent hydration mismatch
  if (!resolvedTheme) return null

  return (
    <ThemeProvider theme={resolvedTheme === 'dark' ? darkTheme : lightTheme}>
      <Datatable
        queryKey={queryKey}
        fetchUrl={fetchUrl}
        columnConfig={columnConfig}
        initialPageSize={initialPageSize}
        exportEndpoint={exportEndpoint}
        deleteEndpoint={deleteEndpoint}
        deleteType={deleteType}
        trashView={trashView}
        createAction={createAction}
        restoreRedirect={restoreRedirect}
        deleteRedirect={deleteRedirect}
        backLink={backLink}
      />
    </ThemeProvider>
  )
}

export default DatatableWrapper
