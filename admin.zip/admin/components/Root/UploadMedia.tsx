"use client";

import { Button } from "@/components/ui/button";
import { showToast } from "@/lib/showToast";
import { sonnerToast } from "@/lib/sonnerToast";
import { useQueryClient } from "@tanstack/react-query";
import axios from "axios";
import { CldUploadWidget } from "next-cloudinary";
import { FiPlus } from "react-icons/fi";

const UploadMedia = () => {
  const queryClient = useQueryClient()

  const handleSuccess = async (result) => {
    if (result?.event !== "success") return;

    const info = result.info;
    if (!info?.secure_url) return;

    const uploadedFile = {
      asset_id: result.info.asset_id,
      public_id: result.info.public_id,
      secure_url: result.info.secure_url,
      folder: result.info.folder || null,
      thumbnail_url: result.info.thumbnail_url || result.info.secure_url,
    };

    try {
      const { data } = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/media/create`, [uploadedFile], {
        withCredentials: true
      });

      if (!data.success) {
        throw new Error(data.message);
      }

      // 🔥 Correct invalidation
      queryClient.invalidateQueries({
        queryKey: ["media-data"],
      });

      sonnerToast("success", data.message);
      //showToast("success", data.message);
    } catch (error: any) {
      console.error("Upload DB error:", error);

      showToast("error", error.response?.data?.message || error.message);
    }
  };

  return (
    <CldUploadWidget
      signatureEndpoint="/api/cloudinary/signature"
      uploadPreset={process.env.NEXT_PUBLIC_CLOUDINARY_UPDATE_PRESET}
      onError={(error: any) => {
        showToast("error", error.response?.data?.message || error.message);
      }}
      onSuccess={handleSuccess}
      options={{
        folder: "brokerage_img",
        multiple: true,
        sources: ["local", "url", "unsplash", "google_drive"],
        styles: {
          palette: {
            window: "#111827", // Gray 900
            windowBorder: "#374151", // Gray 700
            tabIcon: "#FFFFFF",
            menuIcons: "#D1D5DB",
            textDark: "#000000",
            textLight: "#FFFFFF",
            link: "#4F46E5", // Indigo 600
            action: "#4F46E5",
            inactiveTabIcon: "#9CA3AF",
            error: "#EF4444",
            inProgress: "#3B82F6",
            complete: "#10B981",
            sourceBg: "#1F2937", // Gray 800
          },
          frame: {
            background: "#111827",
          },
        },
      }}
    >
      {({ open }) => {
        return (
          <Button onClick={() => open()} className="cursor-pointer">
            <FiPlus />
            Upload Media
          </Button>
        );
      }}
    </CldUploadWidget>
  );
};

export default UploadMedia;
