"use client";

import React from "react";

interface BasicInformationFormProps {
  data: any;
  setData: React.Dispatch<React.SetStateAction<any>>;
  errors: Record<string, string>;
  setErrors: React.Dispatch<React.SetStateAction<Record<string, string>>>;
  onNext: () => void;
}

export default function BasicInformationForm({
  data,
  setData,
  errors,
  setErrors,
  onNext,
}: BasicInformationFormProps) {
  const handleChange = (field, value) => {
    setData((prev) => ({
      ...prev,
      [field]: value,
    }));

    // 🔥 Clear error for this field
    setErrors((prev) => ({
      ...prev,
      [field]: undefined,
    }));
  };

  // Determine dynamic labels/placeholders based on the selected label
  const isRent = data.label === "Rent";
  const perSftLabel = isRent ? "Rent Price Per Month" : "Per sft Price";
  const perSftPlaceholder = isRent ? "e.g, 85,000 BDT" : "e.g, 65000";
  const totalPriceLabel = isRent ? "Service Carge" : "Total Price";
  const totalPricePlaceholder = isRent ? "e.g, 8,000 BDT" : "e.g, 1.2 Crore";

  return (
    <div className="bg-card text-card-foreground rounded-xl shadow p-6 mt-6 border border-border">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Property Type */}
        <div>
          <label className="block font-medium mb-2">Property Type</label>
          <select
            value={data.propertyType || ""}
            onChange={(e) => handleChange("propertyType", e.target.value)}
            className="w-full border border-input bg-background rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="">Select Type</option>
            <option value="Residential">Residential</option>
            <option value="Commercial">Commercial</option>
          </select>

          {errors.propertyType && (
            <p className="text-destructive text-sm mt-1">{errors.propertyType}</p>
          )}
        </div>

        {/* Location */}
        <div>
          <label className="block font-medium mb-2">Location</label>
          <select
            value={data.location || ""}
            onChange={(e) => handleChange("location", e.target.value)}
            className="w-full border border-input bg-background rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="">Select Location</option>
            <option value="Dhaka">Dhaka</option>
            <option value="Chattogram">Chattogram</option>
            <option value="Narayanganj">Narayanganj</option>
            <option value="Tangail">Tangail</option>
            <option value="Mohammadpur">Mohammadpur</option>
          </select>

          {errors.location && (
            <p className="text-destructive text-sm mt-1">{errors.location}</p>
          )}
        </div>

        {/* Status */}
        <div>
          <label className="block font-medium mb-2">Status</label>
          <select
            value={data.status || ""}
            onChange={(e) => handleChange("status", e.target.value)}
            className="w-full border border-input bg-background rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="">Select Status</option>
            <option value="New">New</option>
            <option value="Ongoing">Ongoing</option>
            <option value="Used">Used</option>
            <option value="Exclusive">Exclusive</option>
            <option value="Red hot">Red hot</option>
            <option value="Marketplace">Marketplace</option>
          </select>

          {errors.status && (
            <p className="text-destructive text-sm mt-1">{errors.status}</p>
          )}
        </div>

        {/* Label */}
        <div>
          <label className="block font-medium mb-2">Label</label>
          <select
            value={data.label || ""}
            onChange={(e) => handleChange("label", e.target.value)}
            className="w-full border border-input bg-background rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="">Select Label</option>
            <option value="Rent">Rent</option>
            <option value="Sell">Sell</option>
            <option value="Buy">Buy</option>
          </select>

          {errors.label && (
            <p className="text-destructive text-sm mt-1">{errors.label}</p>
          )}
        </div>

        {/* Property Title */}
        <div className="md:col-span-2">
          <label className="block font-medium mb-2">Property Title</label>
          <input
            type="text"
            value={data.propertyTitle || ""}
            onChange={(e) => handleChange("propertyTitle", e.target.value)}
            className="w-full border border-input bg-background rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-primary"
            placeholder="Property Title"
          />
          {errors.propertyTitle && (
            <p className="text-destructive text-sm mt-1">
              {errors.propertyTitle}
            </p>
          )}
        </div>

        {/* Area Size */}
        <div>
          <label className="block font-medium mb-2">Area Size (Sft)</label>
          <input
            type="number"
            value={data.areaSize || ""}
            onChange={(e) => handleChange("areaSize", e.target.value)}
            className="w-full border border-input bg-background rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-primary"
            placeholder="e.g. 1200"
          />
          {errors.areaSize && (
            <p className="text-destructive text-sm mt-1">{errors.areaSize}</p>
          )}
        </div>

        {/* Per Sft Price */}
        <div>
          <label className="block font-medium mb-2">{perSftLabel}</label>
          <input
            type="text"
            value={data.perSftPrice || ""}
            onChange={(e) => handleChange("perSftPrice", e.target.value)}
            className="w-full border border-input bg-background rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-primary"
            placeholder={perSftPlaceholder}
          />
          {errors.perSftPrice && (
            <p className="text-destructive text-sm mt-1">
              {errors.perSftPrice}
            </p>
          )}
        </div>

        {/* Parking Price (Conditionally Rendered) */}
        {isRent && (
          <div>
            <label className="block font-medium mb-2">Parking Price</label>
            <input
              type="text"
              value={data.parkPrice || ""}
              onChange={(e) => handleChange("parkPrice", e.target.value)}
              className="w-full border border-input bg-background rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder="e.g, 5,000 BDT"
            />
            {errors.parkPrice && (
              <p className="text-destructive text-sm mt-1">{errors.parkPrice}</p>
            )}
          </div>
        )}

        {/* Total Price */}
        <div>
          <label className="block font-medium mb-2">{totalPriceLabel}</label>
          <input
            type="text"
            value={data.totalPrice || ""}
            onChange={(e) => handleChange("totalPrice", e.target.value)}
            className="w-full border border-input bg-background rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-primary"
            placeholder={totalPricePlaceholder}
          />
          {errors.totalPrice && (
            <p className="text-destructive text-sm mt-1">{errors.totalPrice}</p>
          )}
        </div>

        {/* Address */}
        <div>
          <label className="block font-medium mb-2">Address</label>
          <input
            type="text"
            value={data.address || ""}
            onChange={(e) => handleChange("address", e.target.value)}
            className="w-full border border-input bg-background rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-primary"
            placeholder="Detailed Address"
          />
          {errors.address && (
            <p className="text-destructive text-sm mt-1">{errors.address}</p>
          )}
        </div>
      </div>

      {/* Next Button */}
      <div className="mt-8 flex justify-end">
        <button
          onClick={onNext}
          className="bg-primary text-primary-foreground px-8 py-3 rounded-lg font-semibold hover:bg-primary/90 transition-colors"
        >
          Next Step: Description
        </button>
      </div>
    </div>
  );
}
