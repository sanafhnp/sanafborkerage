"use client";
import { zSchema } from "@/lib/zodSchema";
import { zodResolver } from "@hookform/resolvers/zod";
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { Form } from "../ui/form";
import ButtonLoading from "./ButtonLoading";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "../ui/form";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "../ui/input-otp";
import { showToast } from "@/lib/showToast";
import axios from "axios";

const OTPVerification = ({ email, onSubmit, loading }) => {
  const [isResendOtp, setIsResendOtp] = useState(false);
  const [timer, setTimer] = useState(0)

  const formSchema = zSchema.pick({
    otp: true,
    email: true,
  });

  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      otp: "",
      email: email,
    },
  });

  const handleOtpVerification = async (values) => {
    await onSubmit(values);
  };

  const resendOTP = async () => {
    try {
      const emailValue = form.getValues("email");
      const { data } = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/auth/resend-otp`, {
        email: emailValue,
      }, { withCredentials: true });

      setIsResendOtp(true);

      if (!data.success) {
        showToast("error", data.message);
        return;
      }

      showToast("success", data.message);

      // start 60s timer
      setTimer(60);

      const interval = setInterval(() => {
        setTimer((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } catch (error: any) {
      const message =
        error.response?.data?.message ||
        error.message ||
        "Something went wrong";

      showToast("error", message);
    } finally {
      setIsResendOtp(false);
    }
  };

  return (
    <div>
      <Form {...form}>
        <form
          onSubmit={form.handleSubmit(handleOtpVerification)}
          className="space-y-3"
        >
          <div className="text-center">
            <h1 className="font-bold">Please complete verifation</h1>
            <p className="text-sm text-violet-700">
              We have sent an One-Time Password (OTP) to your registered email
              address. The OTP is valid for 10 minutes only.
            </p>
          </div>
          <FormField
            control={form.control}
            name="otp"
            render={({ field }) => (
              <FormItem className="flex flex-col items-center space-y-4">
                <FormLabel className="text-center text-lg font-semibold">
                  Enter OTP
                </FormLabel>

                <FormControl>
                  <InputOTP
                    maxLength={6}
                    value={field.value}
                    onChange={field.onChange}
                    className="justify-center"
                  >
                    <InputOTPGroup className="gap-3">
                      {[0, 1, 2, 3, 4, 5].map((index) => (
                        <InputOTPSlot
                          key={index}
                          index={index}
                          className="w-12 h-12 text-xl font-bold text-center 
                       border rounded-lg 
                       focus:ring-2 focus:ring-blue-500 
                       transition-all"
                        />
                      ))}
                    </InputOTPGroup>
                  </InputOTP>
                </FormControl>

                <FormMessage className="text-center" />
              </FormItem>
            )}
          />

          <ButtonLoading
            type="submit"
            text="Verify OTP"
            loading={loading}
            className="w-full cursor-pointer"
          />
          <button
            type="button"
            disabled={isResendOtp || timer > 0}
            onClick={resendOTP}
            className="px-4 py-2 rounded-md bg-primary text-white text-sm
             hover:opacity-90 active:scale-95 transition-all
             disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isResendOtp
              ? "Resending..."
              : timer > 0
                ? `Resend OTP in ${timer}s`
                : "Resend OTP"}
          </button>
        </form>
      </Form>
    </div>
  );
};

export default OTPVerification;
