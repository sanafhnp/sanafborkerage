"use client";

import React, { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { zSchema } from "@/lib/zodSchema";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import ButtonLoading from "@/components/Application/ButtonLoading";
import z from "zod";
// Eye icons.
import { FaRegEyeSlash } from "react-icons/fa";
import { FaRegEye } from "react-icons/fa6";
import axios from "axios";
import { showToast } from "@/lib/showToast";
import { useRouter } from "next/navigation";
import { WEBSITE_LOGIN } from "@/routes/WebsiteRoute";


const UpdatePassword = ({ email }) => {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [isTypePassword, setIsTypePassword] = useState(true)

  const formSchema = zSchema.pick({
    email: true, password: true
  }).extend({
    confirmPassword: z.string()
  }).refine((data) => data.password === data.confirmPassword, {
    message: 'Password and confirm password must be same.',
    path: ['confirmPassword']
  })

  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: email,
      password: '',
      confirmPassword: ''
    },
  });

  const handlePasswordUpdate = async (values: any) => {
    //console.log(values)
    try {
      setLoading(true);

      const { data } = await axios.put(
        `${process.env.NEXT_PUBLIC_API_URL}/auth/reset-password/update-password`,
        values,
        { withCredentials: true }
      );

      if (!data.success) {
        showToast("error", data.message);
        return;
      }

      form.reset();
      showToast("success", data.message);
      router.push(WEBSITE_LOGIN);
    } catch (error: any) {
      const message =
        error.response?.data?.message ||
        error.message ||
        "Something went wrong";

      showToast("error", message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className='w-100'>
      <CardContent>
        <div className="text-center">
          <h1 className="text-3xl font-bold">Update Password</h1>
          <p>Create new password by filling brllow form.</p>
        </div>
        <div className="mt-5">
          <Form {...form}>
          <form onSubmit={form.handleSubmit(handlePasswordUpdate)} className="space-y-3">

            {/* Password Field */}
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl>
                    <Input
                      type='password'
                      placeholder="••••••••"
                      {...field}
                    />
                  </FormControl>
                  <button 
                    type="button" 
                    className="absolute top-1/2 right-2 cursor-pointer"
                  />
                  <FormMessage />
                </FormItem>
              )}
            />
            {/* Confirm Password Field */}
            <FormField
              control={form.control}
              name="confirmPassword"
              render={({ field }) => (
                <FormItem className='relative'>
                  <FormLabel>Confirm Password</FormLabel>
                  <FormControl>
                    <Input
                      type={isTypePassword ? 'password' : 'text'}
                      placeholder="••••••••"
                      {...field}
                    />
                  </FormControl>
                  <button 
                    type="button" 
                    className="absolute top-1/2 right-2 cursor-pointer"
                    onClick={() => setIsTypePassword(!isTypePassword)}
                  >
                    {isTypePassword ? 
                      <FaRegEyeSlash /> : <FaRegEye /> 
                    }
                  </button>
                  <FormMessage />
                </FormItem>
              )}
            />
            <ButtonLoading 
              type='submit'
              text='Update password'
              loading={loading}
              className='w-full cursor-pointer'
            />
          </form>
        </Form>
        </div>
      </CardContent>
    </Card>
  );
};

export default UpdatePassword;
