"use client";

import React from "react";

interface PreviewSubmitFormProps {
  onBack: () => void;
  onPreview?: () => void;
  onSubmit: () => void;
  featuredImage: any;
  galleryImages: any[];
}

export default function PreviewSubmitForm({
  onBack,
  onPreview,
  onSubmit,
  featuredImage,
  galleryImages = [],
}: PreviewSubmitFormProps) {
  return (
    <div className="bg-card text-card-foreground rounded-xl shadow p-6 mt-6 border border-border">
      <h2 className="text-xl font-semibold mb-6 border-b pb-4">Preview & Submit</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Featured Image */}
        <div>
          <h3 className="font-semibold mb-3">Featured Image</h3>
          {featuredImage ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={featuredImage instanceof File ? URL.createObjectURL(featuredImage) : featuredImage.url}
              alt="Featured"
              className="w-full h-48 object-cover rounded-lg border border-border shadow-sm"
            />
          ) : (
            <div className="w-full h-48 bg-muted flex items-center justify-center rounded-lg border border-dashed border-border text-muted-foreground">
              No Featured Image
            </div>
          )}
        </div>

        {/* Gallery */}
        <div>
          <h3 className="font-semibold mb-3">Gallery</h3>
          {galleryImages && galleryImages.length > 0 ? (
            <div className="grid grid-cols-3 gap-3">
              {galleryImages
                .filter(Boolean) // 🔥 remove null values
                .map((img, index) => (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    key={index}
                    src={img instanceof File ? URL.createObjectURL(img) : img.url}
                    alt="Gallery"
                    className="w-full h-24 object-cover rounded-lg border border-border shadow-sm"
                  />
                ))}
            </div>
          ) : (
            <div className="w-full h-48 bg-muted flex items-center justify-center rounded-lg border border-dashed border-border text-muted-foreground">
              No Gallery Images
            </div>
          )}
        </div>
      </div>

      {/* Buttons */}
      <div className="flex flex-wrap gap-4 mt-10 pt-6 border-t">
        <button
          onClick={onBack}
          className="bg-secondary text-secondary-foreground px-8 py-3 rounded-lg font-semibold hover:bg-secondary/80 transition-all shadow-sm"
        >
          Back to Step 3
        </button>

        <button
          onClick={onPreview}
          className="bg-accent text-accent-foreground px-8 py-3 rounded-lg font-semibold hover:bg-accent/80 transition-all shadow-sm"
        >
          Preview Property
        </button>

        <button
          onClick={onSubmit}
          className="bg-primary text-primary-foreground px-8 py-3 rounded-lg font-semibold hover:bg-primary/90 transition-all shadow-md ml-auto"
        >
          Submit for Publish
        </button>
      </div>
    </div>
  );
}
