"use client";

const steps = [
  "Basic Information",
  "Description",
  "Attachment",
  "Submit",
];

export default function MultiStepStepper({ currentStep, onStepClick }) {
  return (
    <div className="w-full bg-card border border-border rounded-xl p-8 shadow-sm">
      <div className="relative flex items-center justify-between">
        {/* Background Line */}
        <div className="absolute top-6 left-0 w-full h-1 bg-muted rounded-full"></div>

        {/* Active Progress Line */}
        <div
          className="absolute top-6 left-0 h-1 bg-primary rounded-full transition-all duration-500 ease-in-out"
          style={{
            width: `${((currentStep - 1) / (steps.length - 1)) * 100}%`,
          }}
        />

        {steps.map((label, index) => {
          const stepNumber = index + 1;
          const isActive = stepNumber <= currentStep;
          const isCompleted = stepNumber < currentStep;

          return (
            <div
              key={index}
              className="relative flex flex-col items-center flex-1 cursor-pointer group"
              onClick={() => onStepClick?.(stepNumber)}
            >
              {/* Circle */}
              <div
                className={`z-10 flex items-center justify-center w-12 h-12 rounded-full border-2 transition-all duration-300 transform group-hover:scale-110
                  ${
                    isActive
                      ? "bg-primary text-primary-foreground border-primary shadow-lg"
                      : "bg-background text-muted-foreground border-muted group-hover:border-primary/50"
                  }
                  ${isCompleted ? "bg-primary/90" : ""}
                `}
              >
                {stepNumber}
              </div>

              {/* Label */}
              <p
                className={`mt-3 text-sm font-semibold transition-colors duration-300 ${
                  isActive ? "text-primary" : "text-muted-foreground group-hover:text-primary/70"
                }`}
              >
                {label}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}