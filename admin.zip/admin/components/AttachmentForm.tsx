"use client";

import React from "react";

interface AttachmentFormProps {
  data: {
    featuredImage?: any;
    galleryImages: any[];
  };
  setData: React.Dispatch<React.SetStateAction<any>>;
  errors: Record<string, string>;
  setErrors: React.Dispatch<React.SetStateAction<Record<string, string>>>;
  onNext: () => void;
  onBack: () => void;
}

export default function AttachmentForm({
  data,
  setData,
  errors,
  setErrors,
  onNext,
  onBack,
}: AttachmentFormProps) {
  const handleChange = (field, value) => {
    setData((prev) => ({
      ...prev,
      [field]: value,
    }));

    // 🔥 Clear error
    setErrors((prev) => {
      const newErrors = { ...prev };
      delete newErrors[field];
      return newErrors;
    });
  };

  const handleGalleryChange = (index, file) => {
    const updated = [...(data.galleryImages || [])];
    updated[index] = file;

    setData((prev) => ({
      ...prev,
      galleryImages: updated,
    }));

    // clear any existing gallery errors
    setErrors((prev) => {
      const newErrors = { ...prev };
      delete newErrors.galleryImages;
      return newErrors;
    });
  };

  const addMoreImage = () => {
    setData((prev) => ({
      ...prev,
      galleryImages: [...(prev.galleryImages || []), null],
    }));
  };

  return (
    <div className="bg-card text-card-foreground rounded-xl shadow p-6 mt-6 border border-border">
      {/* Featured Image */}
      <div className="mb-6">
        <label className="block font-semibold mb-2">Featured Image</label>
        <div className="flex items-center gap-4 mb-3">
          {data.featuredImage && (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={data.featuredImage instanceof File ? URL.createObjectURL(data.featuredImage) : data.featuredImage.url}
              alt="Featured Preview"
              className="w-20 h-20 object-cover rounded border border-border shadow-sm"
            />
          )}
          <input
            type="file"
            accept="image/*"
            onChange={(e) => handleChange("featuredImage", e.target.files[0])}
            className="flex-1 border border-input bg-background rounded-lg p-2 text-sm file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary file:text-primary-foreground hover:file:bg-primary/90"
          />
        </div>
        {errors.featuredImage && (
          <p className="text-destructive text-sm mt-1">{errors.featuredImage}</p>
        )}
      </div>

      {/* Gallery */}
      <div className="mb-6">
        <label className="block font-semibold mb-2">Gallery Images</label>
        <div className="space-y-4">
          {(data.galleryImages || []).map((img, index) => (
            <div key={index} className="flex items-center gap-4">
              {img && (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={img instanceof File ? URL.createObjectURL(img) : img.url}
                  alt={`Gallery ${index}`}
                  className="w-16 h-16 object-cover rounded border border-border shadow-sm"
                />
              )}
              <input
                type="file"
                accept="image/*"
                onChange={(e) => handleGalleryChange(index, e.target.files[0])}
                className="flex-1 border border-input bg-background rounded-lg p-2 text-sm file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary file:text-primary-foreground hover:file:bg-primary/90"
              />
              <button
                type="button"
                onClick={() => {
                  const updated = [...data.galleryImages];
                  updated.splice(index, 1);
                  setData((prev) => ({ ...prev, galleryImages: updated }));
                }}
                className="p-2 text-destructive hover:bg-destructive/10 rounded-full transition-colors"
                title="Remove image"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
          ))}
        </div>
        {errors.galleryImages && (
          <p className="text-destructive text-sm mt-1">{errors.galleryImages}</p>
        )}
        <button
          type="button"
          onClick={addMoreImage}
          className="mt-4 bg-secondary text-secondary-foreground px-4 py-2 rounded-lg text-sm font-medium hover:bg-secondary/80 transition-colors"
        >
          + Add More Image
        </button>
      </div>

      {/* YouTube Link */}
      <div className="mb-6">
        <label className="block font-semibold mb-2">YouTube Video Link</label>
        <input
          type="text"
          value={data.youtubeLink || ""}
          onChange={(e) => handleChange("youtubeLink", e.target.value)}
          className="w-full border border-input bg-background rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-primary"
          placeholder="https://www.youtube.com/watch?v=..."
        />
        {errors.youtubeLink && (
          <p className="text-destructive text-sm mt-1">{errors.youtubeLink}</p>
        )}
      </div>

      {/* Step Buttons */}
      <div className="flex justify-between mt-10">
        <button
          onClick={onBack}
          className="bg-secondary text-secondary-foreground px-8 py-3 rounded-lg font-semibold hover:bg-secondary/80 transition-colors"
        >
          Back to Step 2
        </button>

        <button
          onClick={onNext}
          className="bg-primary text-primary-foreground px-8 py-3 rounded-lg font-semibold hover:bg-primary/90 transition-colors"
        >
          Next Step: Preview
        </button>
      </div>
    </div>
  );
}