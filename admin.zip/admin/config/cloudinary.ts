import { v2 as cloudinary } from "cloudinary";

const { CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET } = process.env;

if (!CLOUDINARY_CLOUD_NAME || !CLOUDINARY_API_KEY || !CLOUDINARY_API_SECRET) {
  const missing = [
    !CLOUDINARY_CLOUD_NAME ? "CLOUDINARY_CLOUD_NAME" : null,
    !CLOUDINARY_API_KEY ? "CLOUDINARY_API_KEY" : null,
    !CLOUDINARY_API_SECRET ? "CLOUDINARY_API_SECRET" : null,
  ].filter(Boolean) as string[];
  throw new Error(
    `Cloudinary configuration missing: ${missing.join(", ")}. Set these in apps/api/.env`
  );
}

cloudinary.config({
  cloud_name: CLOUDINARY_CLOUD_NAME as string,
  api_key: CLOUDINARY_API_KEY as string,
  api_secret: CLOUDINARY_API_SECRET as string,
});

export default cloudinary;
