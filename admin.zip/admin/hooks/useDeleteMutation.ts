import { response } from '@/lib/helperFunction'
import { showToast } from '@/lib/showToast'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import axios from 'axios'

const useDeleteMutation = (queryKey: string, deleteEndpoint: string) => {
    const queryClient = useQueryClient()

    return useMutation({
        mutationFn: async (variables: { ids: string[]; deleteType: string }) => {
            const { data: response } = await axios({
                url: deleteEndpoint,
                method: variables.deleteType === 'PD' ? 'DELETE' : 'PUT',
                data: { ids: variables.ids, deleteType: variables.deleteType },
                withCredentials: true
            })

            if (!response.success) {
                throw new Error(response.message)
            }

            return response
        },
        onSuccess: (data) => {
            showToast('success', data.message)
            queryClient.invalidateQueries({ queryKey: [queryKey] })
        },
        onError: (error) => {
            showToast('error', error.message)
        }
    })
}

export default useDeleteMutation