import axios, { Method } from "axios";
import { useEffect, useMemo, useState } from "react";

interface FetchState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
}

const useFetch = <T = any>(
  url: string,
  method: Method = "GET",
  options: any = {}
) => {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [refreshIndex, setRefreshIndex] = useState<number>(0);

  const optionsString = JSON.stringify(options);
  const requestOptions = useMemo(() => {
    const opts = { ...options };
    if (method === "POST" && !opts.data) {
      opts.data = {};
    }
    return opts;
  }, [method, optionsString]);

  useEffect(() => {
    const apiCall = async () => {
      setLoading(true);
      setError(null);

      try {
        let finalUrl;
        if (url.startsWith("http")) {
          finalUrl = new URL(url).href;
        } else {
          const path = url.startsWith("/api")
            ? url
            : `/api${url.startsWith("/") ? "" : "/"}${url}`;
          finalUrl = new URL(path, window.location.origin).href;
        }

        const { data: response } = await axios({
          url: finalUrl,
          method,
          withCredentials: true,
          ...requestOptions,
        });

        if (!response.success) {
          throw new Error(response.message);
        }

        setData(response);
      } catch (error: any) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    apiCall();
  }, [url, method, refreshIndex, requestOptions]);

  const refetch = () => {
    setRefreshIndex((prev) => prev + 1);
  };

  return { data, loading, error, refetch };
};

export default useFetch;