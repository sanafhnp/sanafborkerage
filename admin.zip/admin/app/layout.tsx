import { ReactNode } from "react";
import { ToastContainer } from "react-toastify";
import "./globals.css";
import { Assistant } from "next/font/google";
import GlobalProvider from "@/components/Application/GlobalProvider";
import { Toaster } from "sonner";
import { Metadata } from "next";

const assistantFont = Assistant({
  weight: ["400", "500", "600", "700", "800"],
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Brokerage Admin | Real Estate",
  description: "Brokerage Admin | Real Estate",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className={`${assistantFont.className} antialiased`}>
        <GlobalProvider>
          <ToastContainer />
          <Toaster position="top-right" />
          {children}
        </GlobalProvider>
      </body>
    </html>
  );
}
