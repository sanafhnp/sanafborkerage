"use client";

import Image from "next/image";
import React, { useState } from "react";
import Logo from "@/public/assets/images/logo-black.png";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { zSchema } from "@/lib/zodSchema";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import ButtonLoading from "@/components/Application/ButtonLoading";
import Link from "next/link";
import { WEBSITE_LOGIN } from "@/routes/WebsiteRoute";
import axios from "axios";
import { showToast } from "@/lib/showToast";
import OTPVerification from "@/components/Application/OTPVerification";
import UpdatePassword from "@/components/Application/UpdatePassword";
import z from "zod";

const ResetPassword = () => {
  const [loading, setLoading] = useState(false);
  const [otpLoading, setOtpLoading] = useState(false);
  const [otpEmail, setOtpEmail] = useState<string | null>(null);
  const [isOtpVerified, setIsOtpVerified] = useState(false);

  const formSchema = zSchema.pick({
    email: true,
  });

  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
    },
  });

  const handleEmailVerification = async (values: z.infer<typeof formSchema>) => {
    //console.log(values)
    try {
      setLoading(true);

      const { data } = await axios.post(
        `${process.env.NEXT_PUBLIC_API_URL}/auth/reset-password/send-otp`,
        values,
        { withCredentials: true }
      );

      if (!data.success) {
        showToast("error", data.message);
        return;
      }

      setOtpEmail(values.email);

      form.reset();
      showToast("success", data.message);
    } catch (error: any) {
      const message =
        error.response?.data?.message ||
        error.message ||
        "Something went wrong";

      showToast("error", message);
    } finally {
      setLoading(false);
    }
  };

  // OTP verification
  const handleOtpVerification = async (values: { otp: string; email: string }) => {
    try {
      setOtpLoading(true);

      const { data } = await axios.post(
        `${process.env.NEXT_PUBLIC_API_URL}/auth/reset-password/verify-otp`,
        values,
        { withCredentials: true }
      );

      if (!data.success) {
        showToast("error", data.message);
        return;
      }

      showToast("success", data.message);
      setIsOtpVerified(true);
    } catch (error: any) {
      const message =
        error.response?.data?.message ||
        error.message ||
        "Something went wrong";

      showToast("error", message);
    } finally {
      setOtpLoading(false);
    }
  };

  return (
      <div className="w-100">
        <div className="flex justify-center">
          <Image src={Logo} alt="logo" className="max-w-37.5" />
        </div>
        {!otpEmail ? (
          <>
            <div className="text-center">
              <h1 className="text-3xl font-bold">Reset Password</h1>
              <p>Enter your email for password reset.</p>
            </div>
            <div className="mt-5">
              <Form {...form}>
                <form
                  onSubmit={form.handleSubmit(handleEmailVerification)}
                  className="space-y-3"
                >
                  {/* Email Field */}
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }: { field: any }) => (
                      <FormItem className="">
                        <FormLabel className="">Email</FormLabel>
                        <FormControl>
                          <Input placeholder="example@email.com" {...field} />
                        </FormControl>
                        <FormMessage className="" />
                      </FormItem>
                    )}
                  />
                  <ButtonLoading
                    type="submit"
                    text="Send OTP"
                    loading={loading}
                    className="w-full cursor-pointer"
                    onclick={() => {}} // Added missing onclick prop
                  />
                  <div className="flex justify-center items-center gap-2">
                    <Link
                      href={WEBSITE_LOGIN}
                      className="text-primary underline"
                    >
                      Back to login
                    </Link>
                  </div>
                </form>
              </Form>
            </div>
          </>
        ) : (
          <>
            {!isOtpVerified ? (
              <OTPVerification
                email={otpEmail}
                onSubmit={handleOtpVerification}
                loading={otpLoading}
              />
            ) : (
              <UpdatePassword email={otpEmail}/>
            )}
          </>
        )}
      </div>
  );
};

export default ResetPassword;
