'use client'

import { Card, CardContent } from "@/components/ui/card"
import { useEffect, useState } from "react"
import verifiedImg from '@/public/assets/images/verified.gif'
import verifiedImgFailed from '@/public/assets/images/verification-failed.gif'
import Image from "next/image"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { WEBSITE_HOME } from "@/routes/WebsiteRoute"
import axios from "axios"
import { useParams } from "next/navigation"

const EmailVerification = () => {
  const [isVerified, setIsVerified] = useState<boolean | null>(null);
  const { token } = useParams();

  useEffect(() => {
    if (!token) return

    const verify = async () => {
      try {
        const { data } = await axios.post(
          `${process.env.NEXT_PUBLIC_API_URL}/auth/verify-email`,
          { token },
          { withCredentials: true }
        );
        setIsVerified(data.success);
      } catch (error: any) {
        setIsVerified(false);
      }
    }

    verify()
  }, [token])

  if (isVerified === null) {
    return <p className="text-center">Verifying...</p>
  }

  return (
    <Card className="w-100">
      <CardContent>

        {isVerified ? (
          <div>
            <div className="flex justify-center items-center">
              <Image
                src={verifiedImg}
                className="h-25 w-auto"
                alt="Verification Success"
                unoptimized
              />
            </div>

            <div className="text-center">
              <h1 className="text-2xl font-bold my-5 text-green-500">
                Email verification success!
              </h1>

              <Button asChild>
                <Link href={WEBSITE_HOME}>Continue Shopping</Link>
              </Button>
            </div>
          </div>
        ) : (
          <div>
            <div className="flex justify-center items-center">
              <Image
                src={verifiedImgFailed}
                className="h-25 w-auto"
                alt="Verification Failed"
                unoptimized
              />
            </div>

            <div className="text-center">
              <h1 className="text-2xl font-bold my-5 text-red-500">
                Email verification failed!
              </h1>
            </div>

            <Button asChild>
              <Link href={WEBSITE_HOME}>Continue Shopping</Link>
            </Button>
          </div>
        )}

      </CardContent>
    </Card>
  )
}

export default EmailVerification