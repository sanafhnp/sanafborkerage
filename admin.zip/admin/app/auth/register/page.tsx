"use client";

import Image from "next/image";
import React, { useState } from "react";
import Logo from "@/public/assets/images/logo-black.png";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { zSchema } from "@/lib/zodSchema";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import ButtonLoading from "@/components/Application/ButtonLoading";
import z from "zod";
// Eye icons.
import { FaRegEyeSlash } from "react-icons/fa";
import { FaRegEye } from "react-icons/fa6";
import Link from "next/link";
import { WEBSITE_LOGIN } from "@/routes/WebsiteRoute";
import axios from "axios";
import { showToast } from "@/lib/showToast";


const RegisterPage = () => {
  const [loading, setLoading] = useState(false)
  const [isTypePassword, setIsTypePassword] = useState(true)

  const formSchema = zSchema.pick({
    name: true, email: true, password: true
  }).extend({
    confirmPassword: z.string()
  }).refine((data) => data.password === data.confirmPassword, {
    message: 'Password and confirm password must be same.',
    path: ['confirmPassword']
  })

  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      email: '',
      password: '',
      confirmPassword: ''
    },
  });

  const handleSubmitRegister = async (values: z.infer<typeof formSchema>) => {
    //console.log(values)
    try {
      setLoading(true)

      const { data } = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/auth/register`, values, { withCredentials: true })

      if (!data.success) {
        showToast('error', data.message)
        return
      }

      form.reset()
      showToast('success', data.message)

    } catch (error: any) {
      const message =
        error.response?.data?.message ||
        error.message ||
        "Something went wrong";

      showToast("error", message);
    } finally {
      setLoading(false)
    }
  };

  return (
    <Card className='w-100'>
      <CardContent>
        <div className="flex justify-center">
          <Image
            src={Logo}
            alt="logo"
            className="max-w-37.5"
          />
        </div>
        <div className="text-center">
          <h1 className="text-3xl font-bold">Create Account</h1>
          <p>Create new account by filling out the form brllow.</p>
        </div>
        <div className="mt-5">
          <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmitRegister)} className="space-y-3">
            
            {/* Full Name */}
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Fullname</FormLabel>
                  <FormControl>
                    <Input placeholder="john doe" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Email Field */}
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input placeholder="example@email.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Password Field */}
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl>
                    <Input
                      type='password'
                      placeholder="••••••••"
                      {...field}
                    />
                  </FormControl>
                  <button 
                    type="button" 
                    className="absolute top-1/2 right-2 cursor-pointer"
                  />
                  <FormMessage />
                </FormItem>
              )}
            />
            {/* Confirm Password Field */}
            <FormField
              control={form.control}
              name="confirmPassword"
              render={({ field }) => (
                <FormItem className='relative'>
                  <FormLabel>Confirm Password</FormLabel>
                  <FormControl>
                    <Input
                      type={isTypePassword ? 'password' : 'text'}
                      placeholder="••••••••"
                      {...field}
                    />
                  </FormControl>
                  <button 
                    type="button" 
                    className="absolute top-1/2 right-2 cursor-pointer"
                    onClick={() => setIsTypePassword(!isTypePassword)}
                  >
                    {isTypePassword ? 
                      <FaRegEyeSlash /> : <FaRegEye /> 
                    }
                  </button>
                  <FormMessage />
                </FormItem>
              )}
            />
            <ButtonLoading 
              type='submit'
              text='Create Account'
              loading={loading}
              className='w-full cursor-pointer'
            />
            <div className="flex justify-center items-center gap-2">
              <p>Already have an account?</p>
              <Link href={WEBSITE_LOGIN} className="text-primary underline">Login?</Link>
            </div>
          </form>
        </Form>
        </div>
      </CardContent>
    </Card>
  );
};

export default RegisterPage;
