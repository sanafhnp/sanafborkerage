"use client";

import Image from "next/image";
import React, { useState } from "react";
import Logo from "@/public/assets/images/logo-black.png";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { zSchema } from "@/lib/zodSchema";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import ButtonLoading from "@/components/Application/ButtonLoading";
import z from "zod";
// Eye icons.
import { FaRegEyeSlash } from "react-icons/fa";
import { FaRegEye } from "react-icons/fa6";
import Link from "next/link";
import { USER_DASHBOARD, WEBSITE_REGISTER, WEBSITE_RESETPASSWORD } from "@/routes/WebsiteRoute";
import axios from "axios";
import { showToast } from "@/lib/showToast";
import OTPVerification from "@/components/Application/OTPVerification";
import { useDispatch } from "react-redux";
import { login } from "@/store/reducer/authReducer";
import { useRouter, useSearchParams } from "next/navigation";
import { ADMIN_DASHBOARD } from "@/routes/AdminRoute";

const LoginPage = () => {
  const searchParams = useSearchParams()
  const router = useRouter()
  const dispatch = useDispatch()
  const [loading, setLoading] = useState(false);
  const [otpLoading, setOtpLoading] = useState(false);
  const [isTypePassword, setIsTypePassword] = useState(true);
  const [otpEmail, setOtpEmail] = useState<string | null>(null);


  const formSchema = zSchema
    .pick({
      email: true,
    })
    .extend({
      password: z.string().min(6, "Password must be at least 6 characters."),
    });

  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const handleSubmitLogin = async (values: z.infer<typeof formSchema>) => {
    //console.log(values)
    try {
      setLoading(true);

      const { data } = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/auth/login`, values, { withCredentials: true });

      if (!data.success) {
        showToast("error", data.message);
        return;
      }

      setOtpEmail(values.email);

      form.reset();
      showToast("success", data.message);
    } catch (error: any) {
      const message =
        error.response?.data?.message ||
        error.message ||
        "Something went wrong";

      showToast("error", message);
    } finally {
      setLoading(false);
    }
  };

  // OTP verification
  const handleOtpVerification = async (values: { otp: string; email: string }) => {
    try {
      setOtpLoading(true)

      const { data: otpResponse } = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/auth/verify-otp`, values, { withCredentials: true });

      if (!otpResponse.success) {
        showToast("error", otpResponse.message);
        return;
      }

      setOtpEmail(null);
      dispatch(login(otpResponse.data))

      showToast("success", otpResponse.message);

      const redirect = searchParams.get('redirect')
      if (redirect) {
        router.push(redirect)
      } else {
        router.push(ADMIN_DASHBOARD)
      }

    } catch (error: any) {
      const message =
        error.response?.data?.message ||
        error.message ||
        "Something went wrong";

      showToast("error", message);
    } finally {
      setOtpLoading(false)
    }
  };

  return (
    <Card className="w-100">
      <CardContent>
        <div className="flex justify-center">
          <Image src={Logo} alt="logo" className="max-w-37.5" />
        </div>
        {!otpEmail ? (
          <>
            <div className="text-center">
              <h1 className="text-3xl font-bold">Login Into Account</h1>
              <p>Login into your account by filling out the form brllow.</p>
            </div>
            <div className="mt-5">
              <Form {...form}>
                <form
                  onSubmit={form.handleSubmit(handleSubmitLogin)}
                  className="space-y-3"
                >
                  {/* Email Field */}
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input placeholder="example@email.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Password Field */}
                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem className="relative">
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input
                            type={isTypePassword ? "password" : "text"}
                            placeholder="••••••••"
                            {...field}
                          />
                        </FormControl>
                        <button
                          type="button"
                          className="absolute right-3 top-9 cursor-pointer"
                          onClick={() => setIsTypePassword(!isTypePassword)}
                        >
                          {isTypePassword ? <FaRegEyeSlash /> : <FaRegEye />}
                        </button>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <ButtonLoading
                    type="submit"
                    text="Login"
                    loading={loading}
                    className="w-full cursor-pointer"
                  />
                  <div className="flex justify-center items-center gap-2">
                    <p>Don&apos;t have account?</p>
                    <Link
                      href={WEBSITE_REGISTER}
                      className="text-primary underline"
                    >
                      Create account?
                    </Link>
                  </div>
                  <div className="text-center">
                    <Link href={WEBSITE_RESETPASSWORD} className="text-primary underline">
                      Forgot password?
                    </Link>
                  </div>
                </form>
              </Form>
            </div>
          </>
        ) : (
          <>
            <OTPVerification email={otpEmail} onSubmit={handleOtpVerification} loading={otpLoading}/>
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default LoginPage;
