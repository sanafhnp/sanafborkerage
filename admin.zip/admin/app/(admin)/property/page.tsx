"use client";

import BreadCrumb from "@/components/Application/Root/BreadCrumb";
import DatatableWrapper from "@/components/Application/Root/DatatableWrapper";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { DT_PROPERTY_COLUMN } from "@/lib/column";
import {
  ADMIN_DASHBOARD,
  ADMIN_PROPERTY_ADD,
  ADMIN_PROPERTY_EDIT,
  ADMIN_PROPERTY_SHOW,
  ADMIN_TRASH,
} from "@/routes/AdminRoute";
import Link from "next/link";
import { FiPlus } from "react-icons/fi";
import { useMemo, useCallback } from "react";
import { columnConfig } from "@/lib/helperFunction";
import EditAction from "@/components/Application/Root/EditAction";
import DeleteAction from "@/components/Application/Root/DeleteAction";

const breadCrumbData = [
  { href: ADMIN_DASHBOARD, label: "Home" },
  { href: ADMIN_PROPERTY_SHOW, label: "Property" },
];

const ShowProperty = () => {
  const columns = useMemo(() => {
    return columnConfig(DT_PROPERTY_COLUMN);
  }, []);

  const action = useCallback(
    (row: any, deleteType: string, handleDelete: (ids: string[], type: string) => void) => {
      const actionMenu = [];

      actionMenu.push(
        <EditAction key="edit" href={ADMIN_PROPERTY_EDIT(row.original._id)} />
      );

      actionMenu.push(
        <DeleteAction
          key="delete"
          handleDelete={handleDelete}
          row={row}
          deleteType={deleteType}
        />
      );

      return actionMenu;
    },
    []
  );

  return (
    <div>
      <BreadCrumb breadCrumbData={breadCrumbData} />

      <Card className="py-0 rounded shadow-sm">
        <CardHeader className="pt-3 px-3 border-b [.border-b]:pb-2">
          <div className="flex justify-between items-center">
            <h1 className="text-xl font-semibold">Show Property</h1>
            <Button asChild>
              <Link href={ADMIN_PROPERTY_ADD}>
                <FiPlus className="mr-2 h-4 w-4" />
                New Property
              </Link>
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pb-5">
          <DatatableWrapper
            queryKey="property-data"
            fetchUrl="/property"
            initialPageSize={10}
            columnConfig={columns}
            exportEndpoint="/property/export"
            deleteEndpoint={`${process.env.NEXT_PUBLIC_API_URL}/property/delete`}
            deleteType="SD"
            trashView={`${ADMIN_TRASH}?trashof=property`}
            createAction={action}
          />
        </CardContent>
      </Card>
    </div>
  );
};

export default ShowProperty;
