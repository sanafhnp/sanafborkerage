"use client";

import { useState, useEffect } from "react";
import axios from "axios";
import { useParams, useRouter } from "next/navigation";
import { propertySchema } from "@/lib/property/propertySchema";
import MultiStepStepper from "@/components/MultiStepStepper";
import BasicInformationForm from "@/components/BasicInformationForm";
import DescriptionForm from "@/components/DescriptionForm";
import AttachmentForm from "@/components/AttachmentForm";
import PreviewSubmitForm from "@/components/PreviewSubmitForm";

import BreadCrumb from "@/components/Application/Root/BreadCrumb";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { ADMIN_DASHBOARD, ADMIN_PROPERTY_SHOW } from "@/routes/AdminRoute";
import React from "react";
import Link from "next/link";
import { FiChevronLeft } from "react-icons/fi";
import { showToast } from "@/lib/showToast";
import useFetch from "@/hooks/useFetch";

const breadCrumbData = [
  { href: ADMIN_DASHBOARD, label: "Home" },
  { href: ADMIN_PROPERTY_SHOW, label: "Property" },
  { href: "", label: "Edit Property" },
];

interface PropertyFormData {
  propertyTitle: string;
  propertyType: string;
  status: string;
  areaSize: string;
  perSftPrice: string;
  totalPrice: string;
  parkPrice: string;
  location: string;
  label: string;
  address: string;
  floor: string;
  bed: string;
  bath: string;
  balcony: string;
  description: string;
  phone: string;
  youtubeLink: string;
  features: string[];
  amenities: string[];
  otherFeatures: string[];
  featuredImage?: File | any | null;
  galleryImages: Array<File | any | null>;
}

const EditProperty = () => {
  const { id } = useParams();
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<PropertyFormData>({
    propertyTitle: "",
    propertyType: "",
    status: "",
    areaSize: "",
    perSftPrice: "",
    totalPrice: "",
    parkPrice: "",
    location: "",
    label: "",
    address: "",
    floor: "",
    bed: "",
    bath: "",
    balcony: "",
    description: "",
    phone: "",
    youtubeLink: "",
    features: [],
    amenities: [],
    otherFeatures: [],
    galleryImages: [],
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const { data: propertyData, loading } = useFetch(`/property/${id}`);

  useEffect(() => {
    if (propertyData?.success && propertyData.data) {
      const p = propertyData.data;
      setFormData({
        propertyTitle: p.propertyTitle || "",
        propertyType: p.propertyType || "",
        status: p.status || "",
        areaSize: p.areaSize || "",
        perSftPrice: p.perSftPrice || "",
        totalPrice: p.totalPrice || "",
        parkPrice: p.parkPrice || "",
        location: p.location || "",
        label: p.label || "",
        address: p.address || "",
        floor: p.floor || "",
        bed: p.bed || "",
        bath: p.bath || "",
        balcony: p.balcony || "",
        description: p.description || "",
        phone: p.phone || "",
        youtubeLink: p.youtubeLink || "",
        features: p.features || [],
        amenities: p.amenities || [],
        otherFeatures: p.otherFeatures || [],
        featuredImage: p.featuredImage || null,
        galleryImages: p.galleryImages || [],
      });
    }
  }, [propertyData]);

  const isRent = formData.label === "Rent";

  const validateStep = () => {
    let stepSchema;

    if (step === 1) {
      stepSchema = propertySchema.pick({
        propertyType: true,
        location: true,
        label: true,
        status: true,
        propertyTitle: true,
        areaSize: true,
        perSftPrice: true,
        totalPrice: true,
        address: true,
        ...(isRent ? { parkPrice: true } : {}),
      });
    }

    if (step === 2) {
      stepSchema = propertySchema.pick({
        floor: true,
        bed: true,
        bath: true,
        balcony: true,
        description: true,
        phone: true,
      });
    }

    if (step === 3) {
      // For edit, featuredImage can be either a File or an object with url
      stepSchema = propertySchema.pick({
        youtubeLink: true,
      });
      // Manual check for featuredImage since the schema expects a File
      if (!formData.featuredImage) {
        setErrors({ featuredImage: "Featured image required" });
        return false;
      }
    }

    try {
      stepSchema?.parse(formData);
      setErrors({});
      return true;
    } catch (err: any) {
      const fieldErrors: Record<string, string> = {};
      if (err.issues) {
        err.issues.forEach((e: any) => {
          fieldErrors[e.path[0] as string] = e.message;
        });
      }
      setErrors(fieldErrors);
      return false;
    }
  };

  const validateAll = () => {
    // Manual validation for all steps
    // Since schema expects File for featuredImage, we skip strict zod validation for images during edit if they are already uploaded
    try {
      propertySchema
        .omit({ featuredImage: true, galleryImages: true })
        .parse(formData);
      if (!formData.featuredImage) {
        throw new Error("Featured image required");
      }
      setErrors({});
      return true;
    } catch (err: any) {
      const fieldErrors: Record<string, string> = {};
      if (err.issues) {
        err.issues.forEach((e: any) => {
          fieldErrors[e.path[0] as string] = e.message;
        });
      } else {
        fieldErrors.featuredImage = err.message;
      }
      setErrors(fieldErrors);
      return false;
    }
  };

  const handleFinalSubmit = async () => {
    if (!validateAll()) return;

    const form = new FormData();

    (Object.keys(formData) as Array<keyof PropertyFormData>).forEach((key) => {
      if (
        key !== "featuredImage" &&
        key !== "galleryImages" &&
        formData[key] !== undefined
      ) {
        const value = formData[key];
        if (Array.isArray(value)) {
          value.forEach((item) => form.append(`${key}[]`, item as string));
        } else {
          form.append(key, value as string | Blob);
        }
      }
    });

    if (formData.featuredImage instanceof File) {
      form.append("featuredImage", formData.featuredImage);
    }

    if (formData.galleryImages?.length) {
      formData.galleryImages.forEach((img) => {
        if (img instanceof File) {
          form.append("galleryImages", img);
        }
      });
    }

    try {
      const { data: result } = await axios.put(`/api/property/${id}`, form, {
        withCredentials: true,
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      if (result.success) {
        showToast("success", "Property updated successfully!");
        router.push(ADMIN_PROPERTY_SHOW);
      } else {
        showToast("error", result.message || "Update failed");
      }
    } catch (error: any) {
      console.error(error);
      showToast(
        "error",
        error.response?.data?.message || "Something went wrong during update"
      );
    }
  };

  const nextStep = () => {
    if (!validateStep()) return;
    setStep(step + 1);
  };

  if (loading) {
    return <div className="p-10 text-center">Loading property data...</div>;
  }

  return (
    <div className="flex flex-col gap-5">
      <BreadCrumb breadCrumbData={breadCrumbData} />

      <Card className="rounded shadow-sm border-none bg-transparent">
        <CardHeader className="pt-3 px-3 border-b pb-2 bg-card rounded-t-xl">
          <div className="flex justify-between items-center">
            <h1 className="text-xl font-semibold">Edit Property</h1>
            <Button asChild variant="outline" className="">
              <Link href={ADMIN_PROPERTY_SHOW}>
                <FiChevronLeft className="mr-2 h-4 w-4" />
                Back
              </Link>
            </Button>
          </div>
        </CardHeader>

        <CardContent className="p-0 bg-background/50 rounded-b-xl">
          <div className="min-h-screen p-10">
            <div className="max-w-5xl mx-auto">
              <MultiStepStepper currentStep={step} onStepClick={setStep} />

              <div className="mt-8">
                {step === 1 && (
                  <BasicInformationForm
                    data={formData}
                    setData={setFormData}
                    errors={errors}
                    setErrors={setErrors}
                    onNext={nextStep}
                  />
                )}

                {step === 2 && (
                  <DescriptionForm
                    data={formData}
                    setData={setFormData}
                    errors={errors}
                    setErrors={setErrors}
                    onNext={nextStep}
                    onBack={() => setStep(1)}
                  />
                )}

                {step === 3 && (
                  <AttachmentForm
                    data={formData}
                    setData={setFormData}
                    errors={errors}
                    setErrors={setErrors}
                    onNext={nextStep}
                    onBack={() => setStep(2)}
                  />
                )}

                {step === 4 && (
                  <PreviewSubmitForm
                    onBack={() => setStep(3)}
                    onSubmit={handleFinalSubmit}
                    featuredImage={formData.featuredImage}
                    galleryImages={formData.galleryImages}
                  />
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default EditProperty;
