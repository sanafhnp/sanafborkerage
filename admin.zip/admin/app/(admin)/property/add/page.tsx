"use client";

import { useState } from "react";
import axios from "axios";
import { propertySchema } from "@/lib/property/propertySchema";
import MultiStepStepper from "@/components/MultiStepStepper";
import BasicInformationForm from "@/components/BasicInformationForm";
import DescriptionForm from "@/components/DescriptionForm";
import AttachmentForm from "@/components/AttachmentForm";
import PreviewSubmitForm from "@/components/PreviewSubmitForm";

import BreadCrumb from "@/components/Application/Root/BreadCrumb";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { ADMIN_DASHBOARD, ADMIN_PROPERTY_SHOW } from "@/routes/AdminRoute";
import React from "react";
import Link from "next/link";
import { FiChevronLeft } from "react-icons/fi";
import { showToast } from "@/lib/showToast";

const breadCrumbData = [
  { href: ADMIN_DASHBOARD, label: "Home" },
  { href: ADMIN_PROPERTY_SHOW, label: "Property" },
  { href: "", label: "Add Property" },
];

interface PropertyFormData {
  propertyTitle: string;
  propertyType: string;
  status: string;
  areaSize: string;
  perSftPrice: string;
  totalPrice: string;
  parkPrice: string;
  location: string;
  label: string;
  address: string;
  floor: string;
  bed: string;
  bath: string;
  balcony: string;
  description: string;
  phone: string;
  youtubeLink: string;
  features: string[];
  amenities: string[];
  otherFeatures: string[];
  featuredImage?: File | null;
  galleryImages: (File | null)[];
}

const AddProperty = () => {
  const [step, setStep] = useState(1);

  const [formData, setFormData] = useState<PropertyFormData>({
    propertyTitle: "",
    propertyType: "",
    status: "",
    areaSize: "",
    perSftPrice: "",
    totalPrice: "",
    parkPrice: "",
    location: "",
    label: "",
    address: "",
    floor: "",
    bed: "",
    bath: "",
    balcony: "",
    description: "",
    phone: "",
    youtubeLink: "",
    features: [], // ✅ IMPORTANT
    amenities: [], // ✅ IMPORTANT
    otherFeatures: [], // ✅ IMPORTANT
    galleryImages: [], // ✅ IMPORTANT
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const isRent = formData.label === "Rent";

  const validateStep = () => {
    let stepSchema;

    if (step === 1) {
      stepSchema = propertySchema.pick({
        propertyType: true,
        location: true,
        label: true,
        status: true,
        propertyTitle: true,
        areaSize: true,
        perSftPrice: true,
        totalPrice: true,
        address: true,
        // only require parkPrice when Rent is selected
        ...(isRent ? { parkPrice: true } : {}),
      });
    }

    if (step === 2) {
      stepSchema = propertySchema.pick({
        floor: true,
        bed: true,
        bath: true,
        balcony: true,
        description: true,
        phone: true,
      });
    }

    if (step === 3) {
      stepSchema = propertySchema.pick({
        youtubeLink: true,
        featuredImage: true,
      });
    }

    try {
      stepSchema?.parse(formData);
      setErrors({});
      return true;
    } catch (err: any) {
      const fieldErrors: Record<string, string> = {};
      console.log("Validation Error at Step", step, ":", err);

      if (err.issues) {
        err.issues.forEach((e: any) => {
          fieldErrors[e.path[0] as string] = e.message;
        });
      }

      setErrors(fieldErrors);
      return false;
    }
  };

  const validateAll = () => {
    try {
      propertySchema.parse(formData);
      setErrors({});
      return true;
    } catch (err: any) {
      const fieldErrors: Record<string, string> = {};
      console.log("Validation All Errors:", err);

      if (err.issues) {
        err.issues.forEach((e: any) => {
          fieldErrors[e.path[0] as string] = e.message;
        });
      }

      setErrors(fieldErrors);

      // 🔥 Auto move to first invalid step
      const firstErrorField = Object.keys(fieldErrors)[0];

      const step1Fields = [
        "propertyType",
        "location",
        "status",
        "propertyTitle",
        "areaSize",
        "perSftPrice",
        "totalPrice",
        "address",
        // parkPrice only when Rent is selected
        ...(isRent ? ["parkPrice"] : []),
      ];

      const step2Fields = [
        "floor",
        "bed",
        "bath",
        "balcony",
        "description",
        "phone",
      ];

      const step3Fields = ["featuredImage", "youtubeLink"];

      if (step1Fields.includes(firstErrorField)) setStep(1);
      else if (step2Fields.includes(firstErrorField)) setStep(2);
      else if (step3Fields.includes(firstErrorField)) setStep(3);

      return false;
    }
  };

  const handleFinalSubmit = async () => {
    const isValid = validateAll();
    if (!isValid) return;

    const form = new FormData();

    // 🔥 Append text fields
    (Object.keys(formData) as Array<keyof PropertyFormData>).forEach((key) => {
      if (
        key !== "featuredImage" &&
        key !== "galleryImages" &&
        formData[key] !== undefined
      ) {
        const value = formData[key];
        if (Array.isArray(value)) {
          value.forEach((item) => form.append(`${key}[]`, item as string));
        } else {
          form.append(key, value as string | Blob);
        }
      }
    });

    // 🔥 Append featured image
    if (formData.featuredImage) {
      form.append("featuredImage", formData.featuredImage);
    }

    // 🔥 Append gallery images
    if (formData.galleryImages?.length) {
      formData.galleryImages.forEach((file) => {
        if (file) {
          form.append("galleryImages", file);
        }
      });
    }

    try {
      const { data: result } = await axios.post("/api/property/create", form, {
        withCredentials: true,
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      console.log("Properties: ", result);

      if (result.success) {
        //alert("Property submitted successfully!");
        showToast("success", "Property submitted successfully!");
      } else {
        //alert(result.message || "Submission failed");
        showToast("error", result.message || "Submission failed");
      }
    } catch (error: any) {
      console.error(error);
      //alert(error.response?.data?.message || "Something went wrong during submission");
      showToast(
        "error",
        error.response?.data?.message || "Something went wrong during submission"
      );
    }
  };

  const nextStep = () => {
    if (!validateStep()) return;
    setStep(step + 1);
  };

  return (
    <div className="flex flex-col gap-5">
      <BreadCrumb breadCrumbData={breadCrumbData} />

      <Card className="rounded shadow-sm border-none bg-transparent">
        <CardHeader className="pt-3 px-3 border-b pb-2 bg-card rounded-t-xl">
          <div className="flex justify-between items-center">
            <h1 className="text-xl font-semibold">Add Property</h1>
            <Button asChild variant="outline" className="">
              <Link href={ADMIN_PROPERTY_SHOW}>
                <FiChevronLeft className="mr-2 h-4 w-4" />
                Back
              </Link>
            </Button>
          </div>
        </CardHeader>

        <CardContent className="p-0 bg-background/50 rounded-b-xl">
          <div className="min-h-screen p-10">
            <div className="max-w-5xl mx-auto">
              <MultiStepStepper currentStep={step} onStepClick={setStep} />

              {step === 1 && (
                <BasicInformationForm
                  data={formData}
                  setData={setFormData}
                  errors={errors}
                  setErrors={setErrors}
                  onNext={nextStep}
                />
              )}

              {step === 2 && (
                <DescriptionForm
                  data={formData}
                  setData={setFormData}
                  errors={errors}
                  setErrors={setErrors}
                  onNext={nextStep}
                  onBack={() => setStep(1)}
                />
              )}

              {step === 3 && (
                <AttachmentForm
                  data={formData}
                  setData={setFormData}
                  errors={errors}
                  setErrors={setErrors}
                  onNext={nextStep}
                  onBack={() => setStep(2)}
                />
              )}

              {step === 4 && (
                <PreviewSubmitForm
                  onBack={() => setStep(3)}
                  onSubmit={handleFinalSubmit}
                  featuredImage={formData.featuredImage}
                  galleryImages={formData.galleryImages}
                />
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AddProperty;
