"use client"

import BreadCrumb from "@/components/Application/Root/BreadCrumb";
import DatatableWrapper from "@/components/Application/Root/DatatableWrapper";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { DT_CATEGORY_COLUMN, DT_PROPERTY_COLUMN } from "@/lib/column";
import {
  ADMIN_CATEGORY_SHOW,
  ADMIN_DASHBOARD,
  ADMIN_PROPERTY_SHOW,
  ADMIN_TRASH,
} from "@/routes/AdminRoute";
import { useMemo, useCallback } from "react";
import { columnConfig } from "@/lib/helperFunction";
import DeleteAction from "@/components/Application/Root/DeleteAction";
import { ListItemIcon, MenuItem } from "@mui/material";
import RestoreTrashIcon from "@mui/icons-material/RestoreFromTrash";
import { useSearchParams } from "next/navigation";

const breadCrumbData = [
  { href: ADMIN_DASHBOARD, label: "Home" },
  { href: ADMIN_TRASH, label: "Trash" },
];

const TrashPage = () => {
  const searchParams = useSearchParams();
  const trashOf = searchParams.get("trashof") || "category";

  const config = useMemo(() => {
    switch (trashOf) {
      case "property":
        return {
          columns: DT_PROPERTY_COLUMN,
          queryKey: "property-trash",
          fetchUrl: "/property",
          exportEndpoint: "/property/export",
          deleteEndpoint: `${process.env.NEXT_PUBLIC_API_URL}/property/delete`,
          redirect: ADMIN_PROPERTY_SHOW,
          title: "Property Trash",
        };
      case "category":
      default:
        return {
          columns: DT_CATEGORY_COLUMN,
          queryKey: "category-trash",
          fetchUrl: "/category",
          exportEndpoint: "/category/export",
          deleteEndpoint: `${process.env.NEXT_PUBLIC_API_URL}/category/delete`,
          redirect: ADMIN_CATEGORY_SHOW,
          title: "Category Trash",
        };
    }
  }, [trashOf]);

  const columns = useMemo(() => {
    return columnConfig(config.columns);
  }, [config.columns]);

  const action = useCallback(
    (row: any, deleteType: string, handleDelete: (ids: string[], type: string) => void) => {
      const actionMenu = [];

      actionMenu.push(
        <MenuItem
          key="restore"
          onClick={() => handleDelete([row.original._id], "restore")}
        >
          <ListItemIcon>
            <RestoreTrashIcon color="success" />
          </ListItemIcon>
          Restore
        </MenuItem>
      );

      actionMenu.push(
        <DeleteAction
          key="delete-forever"
          handleDelete={handleDelete}
          row={row}
          deleteType="PD"
        />
      );

      return actionMenu;
    },
    []
  );

  return (
    <div>
      <BreadCrumb breadCrumbData={breadCrumbData} />

      <Card className="py-0 rounded shadow-sm">
        <CardHeader className="pt-3 px-3 border-b [.border-b]:pb-2">
          <div className="flex justify-between items-center">
            <h1 className="text-xl font-semibold">{config.title}</h1>
          </div>
        </CardHeader>
        <CardContent className="pb-5">
          <DatatableWrapper
            queryKey={config.queryKey}
            fetchUrl={config.fetchUrl}
            initialPageSize={10}
            columnConfig={columns}
            exportEndpoint={config.exportEndpoint}
            deleteEndpoint={config.deleteEndpoint}
            deleteType="PD"
            trashView
            restoreRedirect={config.redirect}
            deleteRedirect={config.redirect}
            backLink={config.redirect}
            createAction={action}
          />
        </CardContent>
      </Card>
    </div>
  );
};

export default TrashPage;
