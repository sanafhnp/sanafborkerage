"use client";

import BreadCrumb from "@/components/Application/Root/BreadCrumb";
import ButtonLoading from "@/components/Application/ButtonLoading";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { showToast } from "@/lib/showToast";
import { zSchema } from "@/lib/zodSchema";
import { ADMIN_CATEGORY_SHOW, ADMIN_DASHBOARD } from "@/routes/AdminRoute";
import { zodResolver } from "@hookform/resolvers/zod";
import axios from "axios";
import React, { useEffect, useState } from "react";
import { useForm, useWatch } from "react-hook-form";
import slugify from "slugify";
import Link from "next/link";
import z from "zod";

const breadCrumbData = [
  { href: ADMIN_DASHBOARD, label: "Home" },
  { href: ADMIN_CATEGORY_SHOW, label: "Category" },
  { href: "", label: "Add Category" },
];

const AddCategory = () => {
  const [loading, setLoading] = useState(false);

  const formSchema = zSchema.pick({
    name: true,
    slug: true,
  });

  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      slug: "",
    },
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    console.log(values);
    try {
      setLoading(true);

      const { data } = await axios.post(
        `${process.env.NEXT_PUBLIC_API_URL}/category/create`,
        values,
        { withCredentials: true }
      );

      if (!data.success) {
        showToast("error", data.message);
        return;
      }

      form.reset();
      showToast("success", data.message);
    } catch (error: any) {
      const message =
        error.response?.data?.message ||
        error.message ||
        "Something went wrong";

      showToast("error", message);
    } finally {
      setLoading(false);
    }
  };

  const name = useWatch({
    control: form.control,
    name: "name",
  }).toLowerCase();
  useEffect(() => {
    if (!name) return;

    const generatedSlug = slugify(name, {
      lower: true,
      strict: true,
      trim: true,
    });

    form.setValue("slug", generatedSlug, {
      shouldValidate: true,
    });
  }, [name, form]);

  return (
    <div>
      <BreadCrumb breadCrumbData={breadCrumbData} />
      <div className="flex items-center justify-center">
        <Card className="w-full max-w-md my-5 rounded shadow-sm">
          <CardHeader className="pt-3 px-3 border-b [.border-b]:pb-2">
            <div className="flex justify-between items-center">
              <Button asChild variant="outline" className="">
                <Link href={ADMIN_CATEGORY_SHOW}>Back to Category</Link>
              </Button>
              <h1 className="text-xl font-semibold">Add Category</h1>
            </div>
          </CardHeader>
          <CardContent className="pb-5">
            <Form {...form}>
              <form
                onSubmit={form.handleSubmit(onSubmit)}
                className="space-y-3"
              >
                {/* Name Field */}
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }: { field: any }) => (
                    <FormItem className={undefined}>
                      <FormLabel className={undefined}>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter name" {...field} />
                      </FormControl>
                      <FormMessage className={undefined} />
                    </FormItem>
                  )}
                />
                {/* Slug Field */}
                <FormField
                  control={form.control}
                  name="slug"
                  render={({ field }: { field: any }) => (
                    <FormItem className={undefined}>
                      <FormLabel className={undefined}>Slug</FormLabel>
                      <FormControl>
                        <Input placeholder="Auto generated slug" {...field} readOnly/>
                      </FormControl>
                      <FormMessage className={undefined}/>
                    </FormItem>
                  )}
                />
                <ButtonLoading
                  onClick={form.handleSubmit(onSubmit)}
                  type="submit"
                  text="Add Category"
                  loading={loading}
                  className="cursor-pointer" 
                  onclick={undefined}                
                  />
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AddCategory;
