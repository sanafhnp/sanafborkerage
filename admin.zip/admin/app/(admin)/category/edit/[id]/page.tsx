'use client'

import BreadCrumb from '@/components/Application/Root/BreadCrumb';
import ButtonLoading from '@/components/Application/ButtonLoading';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import useFetch from '@/hooks/useFetch';
import { zSchema } from '@/lib/zodSchema';
import { ADMIN_CATEGORY_SHOW, ADMIN_DASHBOARD } from '@/routes/AdminRoute';
import { zodResolver } from '@hookform/resolvers/zod';
import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useForm, useWatch } from 'react-hook-form';
import { useParams } from 'next/navigation';
import { showToast } from '@/lib/showToast';
import slugify from 'slugify';
import Link from 'next/link';
import { FiChevronLeft } from 'react-icons/fi';
import z from 'zod';

const breadCrumbData = [
  { href: ADMIN_DASHBOARD, label: "Home" },
  { href: ADMIN_CATEGORY_SHOW, label: "Category" },
  { href: '', label: "Edit Category" },
];


const EditCategory = () => {
  const params = useParams();
  const id = params?.id;
  const [loading, setLoading] = useState(false);

  const formSchema = zSchema.pick({
    _id: true,
    name: true,
    slug: true,
  });

  const form = useForm({
    resolver: zodResolver(formSchema) as any,
    defaultValues: {
      _id: id || '',
      name: '',
      slug: '',
    },
  });

  const { errors } = form.formState;
  useEffect(() => {
    if (Object.keys(errors).length > 0) {
      console.log('Form Errors:', errors);
    }
  }, [errors]);

  const { data, loading: fetching, error } = useFetch(`/category/${id}`, 'GET');

  const name = useWatch({
    control: form.control,
    name: 'name',
  })?.toLowerCase() || '';

  useEffect(() => {
    if (!name) return;
    const generatedSlug = slugify(name, {
      lower: true,
      strict: true,
      trim: true,
    });
    form.setValue('slug', generatedSlug, {
      shouldValidate: true,
    });
  }, [name, form]);

  useEffect(() => {
    if (data?.data?._id) {
      form.reset({
        _id: data.data._id,
        name: data.data.name,
        slug: data.data.slug,
      });
    }
  }, [data, form]);

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    try {
      setLoading(true);
      const { data } = await axios.put(
        `${process.env.NEXT_PUBLIC_API_URL}/category/update`,
        values,
        {
          withCredentials: true,
        }
      );
      if (!data.success) {
        showToast("error", data.message);
        return;
      }
      showToast("success", data.message);
    } catch (error: any) {
      const message =
        error.response?.data?.message ||
        error.message ||
        "Something went wrong";
      showToast("error", message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <BreadCrumb breadCrumbData={breadCrumbData}/>
      <div className="flex items-center justify-center">
        <Card className="w-full max-w-md my-5 rounded shadow-sm">
          <CardHeader className="pt-3 px-3 border-b [.border-b]:pb-2">
            <div className="flex justify-between items-center">
              <Button asChild variant="outline" size="sm" className="">
                <Link href={ADMIN_CATEGORY_SHOW}>
                  <FiChevronLeft className="mr-2 h-4 w-4" />
                  Back to Category
                </Link>
              </Button>
              <h1 className="text-xl font-semibold">Edit Category</h1>
            </div>
          </CardHeader>
          <CardContent className="pb-5">
            {fetching ? (
              <div>Loading...</div>
            ) : error ? (
              <div className="text-sm text-red-500">{error}</div>
            ) : (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(async (data) => {
                  await onSubmit({
                    _id: Array.isArray(data._id) ? data._id[0] : data._id,
                    name: data.name,
                    slug: data.slug,
                  });
                })} className="space-y-3">
                  <FormField
                    control={form.control}
                    name="_id"
                    render={({ field }: { field: any }) => (
                      <Input type="hidden" {...field} />
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }: { field: any }) => (
                      <FormItem className="">
                        <FormLabel className="">Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter name" {...field} />
                        </FormControl>
                        <FormMessage className="" />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="slug"
                    render={({ field }: { field: any }) => (
                      <FormItem className="">
                        <FormLabel className="">Slug</FormLabel>
                        <FormControl>
                          <Input placeholder="Auto generated slug" {...field} readOnly />
                        </FormControl>
                        <FormMessage className="" />
                      </FormItem> 
                    )}
                  />
                  <ButtonLoading
                    onclick={() => { }}
                    type="submit"
                    text="Update Category"
                    loading={loading}
                    className="cursor-pointer"
                  />
                </form>
              </Form>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default EditCategory
