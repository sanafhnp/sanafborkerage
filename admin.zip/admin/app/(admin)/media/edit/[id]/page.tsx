"use client";

import BreadCrumb from "@/components/Application/Root/BreadCrumb";
import ButtonLoading from "@/components/Application/ButtonLoading";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import useFetch from "@/hooks/useFetch";
import { zSchema } from "@/lib/zodSchema";
import { ADMIN_DASHBOARD, ADMIN_MEDIA_SHOW } from "@/routes/AdminRoute";
import { zodResolver } from "@hookform/resolvers/zod";
import Image from "next/image";
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import imgPlaceholder from "@/public/assets/images/img-placeholder.webp";
import axios from "axios";
import { showToast } from "@/lib/showToast";
import { useParams } from "next/navigation";

const breadCrumbData = [
  { href: ADMIN_DASHBOARD, label: "Home" },
  { href: ADMIN_MEDIA_SHOW, label: "Media" },
  { href: "", label: "Edit Media" },
];

const EditMedia = () => {
  const [loading, setLoading] = useState(false);
  const { id } = useParams() as { id: string };
  const { data: mediaData } = useFetch(
    `${process.env.NEXT_PUBLIC_API_URL}/media/${id}`
  );
  //console.log("mediaData: ", mediaData);

  const formSchema = zSchema
    .pick({
      _id: true,
      alt: true,
      title: true
    })

  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      _id: id || "",
      alt: "",
      title: ""
    },
  });

  const { errors } = form.formState;
  useEffect(() => {
    if (Object.keys(errors).length > 0) {
      console.log('Form Errors:', errors);
    }
  }, [errors]);

  useEffect(() => {
    if (mediaData && mediaData.success) {
      const data = mediaData.data
      form.reset({
        _id: data._id || id,
        alt: data.alt || "",
        title: data.title || ""
      })
    }
  }, [mediaData, form, id])

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    console.log("Form Values:", values);
    try {
      setLoading(true);

      const { data } = await axios.put(
        `${process.env.NEXT_PUBLIC_API_URL}/media/update`,
        values,
        {
          withCredentials: true,
        }
      );

      if (!data.success) {
        showToast("error", data.message);
        return;
      }

      showToast("success", data.message);
    } catch (error: any) {
      const message =
        error.response?.data?.message ||
        error.message ||
        "Something went wrong";

      showToast("error", message);
    } finally {
      setLoading(false);
    }
  };


  return (
    <div>
      <BreadCrumb breadCrumbData={breadCrumbData} />
      <Card className="py-0 rounded shadow-sm">
        <CardHeader className="pt-3 px-3 border-b [.border-b]:pb-2">
          <h1 className="text-xl font-semibold">Edit Media</h1>
        </CardHeader>
        <CardContent className="pb-5">
          <Form {...form}>
                <form
                  onSubmit={form.handleSubmit(onSubmit)}
                  className="space-y-3"
                >
                  <input type="hidden" {...form.register("_id")} />
                  <Image
                    src={mediaData?.data?.secure_url || imgPlaceholder}
                    width={150}
                    height={150}
                    alt={mediaData?.alt || 'Image'}
                  />
                  {/* Alt Field */}
                  <FormField
                    control={form.control}
                    name="alt"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Alt</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter alt" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  {/* Title Field */}
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Title</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter title" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <ButtonLoading
                    type="submit"
                    text="Update Media"
                    loading={loading}
                    className="cursor-pointer"
                  />
                </form>
              </Form>
        </CardContent>
      </Card>
    </div>
  );
};

export default EditMedia;
