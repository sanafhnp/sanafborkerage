"use client";

import BreadCrumb from "@/components/Application/Root/BreadCrumb";
import Media from "@/components/Application/Root/Media";
import UploadMedia from "@/components/Application/Root/UploadMedia";
import ButtonLoading from "@/components/Application/ButtonLoading";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import useDeleteMutation from "@/hooks/useDeleteMutation";
import { ADMIN_DASHBOARD, ADMIN_MEDIA_SHOW } from "@/routes/AdminRoute";
import { useInfiniteQuery } from "@tanstack/react-query";
import axios from "axios";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import React, { useState } from "react";

const breadCrumbData = [
  { href: ADMIN_DASHBOARD, label: "Home" },
  { href: "", label: "Media" },
];

interface MediaItem {
  _id: string;
  [key: string]: any;
}

interface MediaResponse {
  mediaData: MediaItem[];
  hasMore: boolean;
}

const MediaPage = () => {
  const [selectedMedia, setSelectedMedia] = useState<string[]>([]);
  const [selectAll, setSelectAll] = useState(false);
  const searchParams = useSearchParams();

  const trashOf = searchParams?.get("trashof");
  const deleteType = trashOf ? "PD" : "SD";

  const fetchMedia = async (page: number, deleteType: string): Promise<MediaResponse> => {
    const { data: response } = await axios.get(
      `${process.env.NEXT_PUBLIC_API_URL}/media?page=${page}&&limit=10&&deleteType=${deleteType}`,
      { withCredentials: true }
    );
    //console.log("response: ", response);
    return response;
  };

  const {
    data,
    error,
    fetchNextPage,
    hasNextPage,
    isFetching,
    isFetchingNextPage,
    status,
  } = useInfiniteQuery<MediaResponse>({
    queryKey: ["media-data", deleteType],
    queryFn: async ({ pageParam }: { pageParam: unknown }) =>
      await fetchMedia(pageParam as number, deleteType),
    initialPageParam: 0,
    getNextPageParam: (lastPage, pages) => {
      const nextPage = pages.length;
      return lastPage.hasMore ? nextPage : undefined;
    },
  });

  const handleSelectAll = () => {
    const allIds: string[] =
      data?.pages?.flatMap((page) =>
        page.mediaData.map((media) => media._id)
      ) || [];
    if (!allIds.length) return;

    const isAllSelected =
      allIds.length > 0 && selectedMedia.length === allIds.length;

    if (isAllSelected) {
      setSelectedMedia([]);
    } else {
      setSelectedMedia(allIds);
    }
  };

  const deleteMutation = useDeleteMutation(
    "media-data",
    `${process.env.NEXT_PUBLIC_API_URL}/media/delete`
  );
  const handleDelete = (ids: string[], deleteType: string) => {
    let c = true;
    if (deleteType === "PD") {
      c = confirm("Are you sure you want to delete the data permanently?");
    }

    if (c) {
      deleteMutation.mutate({ ids, deleteType } as any);
    }

    setSelectAll(false);
    setSelectedMedia([]);
  };

  return (
    <div>
      <BreadCrumb breadCrumbData={breadCrumbData} />
      <Card className="py-0 rounded shadow-sm">
        <CardHeader className="pt-3 px-3 border-b [.border-b]:pb-2">
          <div className="flex justify-between items-center">
            <h4 className="font-semibold text-xl uppercase">
              {deleteType === "SD" ? "Media" : "Media Trash"}
            </h4>
            <div className="flex items-center gap-5">
              {deleteType === "SD" && <UploadMedia />}
              <div className="flex gap-3">
                {deleteType === "SD" ? (
                  <Button type="button" variant="destructive" className="">
                    <Link href={`${ADMIN_MEDIA_SHOW}?trashof=media`}>
                      Trash
                    </Link>
                  </Button>
                ) : (
                  <Button type="button" className="">
                    <Link href={`${ADMIN_MEDIA_SHOW}`}>Back To Media</Link>
                  </Button>
                )}
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent className='pb-5'>
          {selectedMedia.length > 0 && (
            <div className="py-2 px-3 rounded flex justify-between items-center">
              <Label className="flex items-center gap-2">
                <Checkbox
                  checked={selectAll}
                  onCheckedChange={handleSelectAll}
                  className="border-primary"
                />
                Select All
              </Label>
              <div className="flex gap-2">
                {deleteType === "SD" ? (
                  <Button
                    variant="destructive"
                    onClick={() => handleDelete(selectedMedia, deleteType)}
                    className="cursor-pointer"
                  >
                    Move Into Trash
                  </Button>
                ) : (
                  <>
                    <Button
                      className="bg-green-500 hover:bg-green-600"
                      onClick={() => handleDelete(selectedMedia, "RSD")}
                    >
                      Restore
                    </Button>
                    <Button
                      className="cursor-pointer"
                      variant="destructive"
                      onClick={() => handleDelete(selectedMedia, deleteType)}
                    >
                      Delete Permanently
                    </Button>
                  </>
                )}
              </div>
            </div>
          )}
          {status === "pending" ? (
            <div>Loading...</div>
          ) : status === "error" ? (
            <div className="text-sm text-red-500">{error.message}</div>
          ) : (
            <>
              {data?.pages?.flatMap((page) =>
                page.mediaData.map((media) => media._id),
              ).length === 0 && (
                <div className="text-center">Data not found</div>
              )}
              <div className="grid lg:grid-cols-5 sm:grid-cols-3 grid-cols-2 gap-2 mb-5">
                {data?.pages?.map((page, index) => (
                  <React.Fragment key={index}>
                    {page?.mediaData?.map((media) => (
                      <Media
                        key={media._id}
                        media={media}
                        handleDelete={handleDelete}
                        deleteType={deleteType}
                        selectedMedia={selectedMedia}
                        setSelectedMedia={setSelectedMedia}
                      />
                    ))}
                  </React.Fragment>
                ))}
              </div>
            </>
          )}

          {hasNextPage && 
            <ButtonLoading type='button' className='cursor-pointer' loading={isFetching} onclick={() => fetchNextPage()} text='Load More'/>
          }
        </CardContent>
      </Card>
    </div>
  );
};

export default MediaPage;
