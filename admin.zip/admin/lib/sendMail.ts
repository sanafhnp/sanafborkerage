import nodemailer from 'nodemailer'

export const sendMail = async (
  subject: string,
  to: string,
  body: string
) => {
  const transporter = nodemailer.createTransport({
    host: process.env.NODEMAILER_HOST,
    port: Number(process.env.NODEMAILER_PORT),
    secure: false,
    auth: {
      user: process.env.NODEMAILER_EMAIL,
      pass: process.env.NODEMAILER_PASSWORD,
    },
  });

  const options = {
    from: `"BiswasTech" <${process.env.NODEMAILER_EMAIL}>`,
    to: to,
    subject: subject,
    html: body,
  };

  try {
    await transporter.sendMail(options);

    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
};
