import { z } from "zod";

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/jpg", "image/png", "image/webp"];

// predefined lists for checkboxes
export const FEATURES_LIST = [
  "Cable Tv",
  "Electricity Supply",
  "Emergency Exit",
  "Filtered Water",
  "Fire Extinguisher",
  "Gas Supply",
  "Generator",
  "Intercom",
  "Lift",
  "LPG",
  "Parking",
  "Titas",
];

export const AMENITIES_LIST = [
  "Community Hall",
  "Equipped Kitchen Play Area",
  "Fully Equipped Gym",
  "Furnished",
  "Lawn",
  "Kids Pool",
  "Pool",
  "Kids Play Area",
  "Meeting and guest space",
  "Open Air Theater",
  "Outdoor Badminton",
  "Prayer Room",
  "Sauna Zone",
  "Servant Room",
  "South West Corner Plot",
  "Swimming Pool",
  "Swimming Pool",
  "Tiled Floor",
  "Walking Track",
  "Yoga Space",
];

export const OTHER_FEATURES_LIST = [
  "4 Storied Lift",
  "Air Condition Provision",
  "Arm Booth",
  "Built in Kitchen Cabinet",
  "Double-height entrance",
  "Facing North East",
  "Minimart",
  "Prayer Hall",
  "Two way Road",
];


export const propertySchema = z.object({
  // Step 1
  propertyType: z.string().min(1, "Select a Property Type"),
  location: z.string().min(1, "Select a Location"),
  status: z.string().min(1, "Select a Status"),
  label: z.string().min(1, "Select a Label"),
  propertyTitle: z.string().min(3, "Property Name is required"),
  areaSize: z.string().min(1, "Enter a valid Area"),
  perSftPrice: z.string().min(1, "Enter a valid sft price"),
  totalPrice: z.string().min(1, "Total price required"),
  parkPrice: z.string().optional().refine((val) => !val || val.length > 0, "Parking price invalid"),
  address: z.string().optional(),

  // Step 2
  floor: z.string().min(1, "Floor required"),
  bed: z.string().min(1, "Bed required"),
  bath: z.string().min(1, "Bath required"),
  balcony: z.string().min(1, "Balcony required"),
  description: z.string().min(10, "Description required"),
  phone: z.string().refine((val) => !val || val.length >= 11, "Phone must be empty or at least 11 characters"),

  // Step 3
  youtubeLink: z
    .string()
    .optional()
    .or(z.literal(""))
    .refine(
      (val) =>
        !val ||
        /^(https?\:\/\/)?(www\.youtube\.com|youtu\.be)\/.+$/.test(val),
      "Invalid YouTube link"
    ),

  // Features arrays
  features: z.array(z.string()).optional(),
  amenities: z.array(z.string()).optional(),
  otherFeatures: z.array(z.string()).optional(),

  // Attachments
  featuredImage: z
    .instanceof(File, { message: "Featured image required" })
    .refine((file) => file.size <= MAX_FILE_SIZE, "Max 5MB allowed")
    .refine(
      (file) => ACCEPTED_IMAGE_TYPES.includes(file.type),
      "Only jpg, png, webp allowed"
    ),

  galleryImages: z
    .array(z.instanceof(File))
    .optional(),
});