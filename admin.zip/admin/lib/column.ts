
export const DT_CATEGORY_COLUMN = [
    {
        accessorKey: 'name',
        header: 'Category Name'
    },
    {
        accessorKey: 'slug',
        header: 'Slug'
    }
]

 export const DT_PROPERTY_COLUMN = [
    {
        accessorKey: 'propertyTitle',
        header: 'Property Name'
    },
    {
        accessorKey: 'totalPrice',
        header: 'Price'
    },
    {
        accessorKey: 'propertyType',
        header: 'Type'
    },
    {
        accessorKey: 'location',
        header: 'Location'
    }
]
