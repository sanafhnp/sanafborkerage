import mongoose from "mongoose"

const MONGODB_URI = process.env.MONGODB_URI

let catched = global.mongoose

if (!catched) {
    catched = global.mongoose = {
        conn: null,
        promise: null
    }
}

export const connectDB = async () => {
    if (catched.conn) return catched.conn
    if (!catched.promise) {
        catched.promise = mongoose.connect(MONGODB_URI, {
            dbName: 'eshop_db',
            bufferCommands: false
        })
    }

    catched.conn = await catched.promise
    
    return catched.conn
}