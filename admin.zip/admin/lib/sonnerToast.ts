import { toast } from "sonner";

export const sonnerToast = (type, message) => {
  if (type === "success") toast.success(message);
  if (type === "error") toast.error(message);
};