import { z } from "zod";

export const zSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, "Name must be at least 2 characters")
    .max(50, "Name must be at most 50 characters"),

  email: z
    .string()
    .trim()
    .min(1, "Email is required")
    .email("Invalid email address"),

  password: z
    .string()
    .min(8, "Password must be at least 8 characters")
    .max(64, "Password is too long")
    .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
    .regex(/[a-z]/, "Password must contain at least one lowercase letter")
    .regex(/[0-9]/, "Password must contain at least one number")
    .regex(/[^A-Za-z0-9]/, "Password must contain at least one special character"),

  otp: z
    .string()
    .trim()
    .regex(/^\d{6}$/, "OTP must be a valid 6-digit number."),

  _id: z.string().min(3, '_id is required'),
  alt: z.string().optional(),
  title: z.string().optional(),
  slug: z.string().min(3, 'Slug is required'),

});