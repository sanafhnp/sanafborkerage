import { NextResponse } from "next/server";
import crypto from "crypto";

interface ResponseData {
  success: boolean;
  message: string;
  data?: any;
  stack?: string;
}

export const response = (
  success: boolean,
  statusCode: number,
  message: string,
  data: any = {}
): NextResponse<ResponseData> => {
  return NextResponse.json({ success, message, data }, { status: statusCode });
};

export const catchError = (
  error: any,
  customMessage?: string
): NextResponse<ResponseData> => {
  console.error("ERROR:", error);

  // Handle duplicate key error (MongoDB)
  if (error.code === 11000) {
    const keys = Object.keys(error.keyPattern).join(", ");
    error.message = `Duplicate fields: ${keys}. These field values must be unique.`;
  }

  const statusCode = error.statusCode || 500;

  if (process.env.NODE_ENV === "development") {
    return response(false, statusCode, error.message, { stack: error.stack });
  }

  return response(false, statusCode, customMessage || "Internal server error.");
};

export const generateOTP = (): string =>
  crypto.randomInt(100000, 1000000).toString();

interface Column {
  accessorKey: string;
  header: string;
  Cell?: ({ renderedCellValue }: { renderedCellValue: any }) => string;
}

export const columnConfig = (
  column: Column[],
  isCreatedAt = false,
  isUpdatedAt = false,
  isDeletedAt = false
): Column[] => {
  const newColumn = [...column];

  if (isCreatedAt) {
    newColumn.push({
      accessorKey: "createdAt",
      header: "Created At",
      Cell: ({ renderedCellValue }) =>
        new Date(renderedCellValue).toLocaleString(),
    });
  }

  if (isUpdatedAt) {
    newColumn.push({
      accessorKey: "updatedAt",
      header: "Updated At",
      Cell: ({ renderedCellValue }) =>
        new Date(renderedCellValue).toLocaleString(),
    });
  }

  if (isDeletedAt) {
    newColumn.push({
      accessorKey: "deletedAt",
      header: "Deleted At",
      Cell: ({ renderedCellValue }) =>
        new Date(renderedCellValue).toLocaleString(),
    });
  }

  return newColumn;
};