import { jwtVerify } from "jose";
import { cookies } from "next/headers";

export const isAuthenticated = async (role: string) => {
  try {
    const cookieStore = await cookies(); // ✅ MUST use await in Next 15
    //console.log('cookieStore: ', cookieStore.getAll())
    const token = cookieStore.get("access_token")?.value;

    if (!token) {
      return { isAuth: false };
    }

    const { payload } = await jwtVerify(
      token,
      new TextEncoder().encode(process.env.SECRET_KEY || "")
    );

    if (role && payload.role !== role) {
      return { isAuth: false };
    }

    return {
      isAuth: true,
      userId: payload._id,
      role: payload.role,
    };
  } catch (error: any) {
    console.log("AUTH ERROR:", error.message);
    return {
      isAuth: false,
      error: error.message,
    };
  }
};